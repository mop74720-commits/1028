#!/usr/bin/env python3
"""Generate this revision's Chinese report from the delivered result records."""
from pathlib import Path
import json,re,hashlib,subprocess,os
ROOT=Path(__file__).resolve().parents[1]
HERE=Path(__file__).resolve().parent

def read(p):return json.loads((ROOT/p).read_text())
def sci(x,digits=4):
    a,b=f'{x:.{digits-1}e}'.split('e')
    return a+r'\times10^{'+str(int(b))+'}'

def main():
    labels={}
    for doc in ['main','supplement']:
        for key,num,page in re.findall(r'\\newlabel\{([^}]+)\}\{\{([^}]+)\}\{([^}]+)\}',(ROOT/'english'/(doc+'_xr.aux')).read_text()):
            labels[key]={'number':num,'page':page,'document':doc}
    baseline=read('reproduction/new_baseline.json')
    inventory=read('reviews/fusion_audit/source_inventory.json')
    mag=read('reproduction/general_birkhoff_experiments/magnetic_method_comparison.json')
    synth=read('reproduction/general_birkhoff_experiments/synthetic_method_comparison.json')
    control=read('reproduction/experiments/control_audit_summary.json')
    budget=read('reproduction/route_budget/normal_form_budget_results.json')
    selection=[]
    for method,cn in [('ordinary_midpoint','普通'),('weighted_midpoint','加权'),('chart_midpoint','图表')]:
        selection.append(('A 无控',cn,mag['cases'][0]['methods'][method][-1]))
    selection.append(('$h_0$','Central4',mag['cases'][2]['methods']['central4'][-1]))
    for i,cn in [(0,'合成无控'),(1,'合成受控')]:
        for method,label in [('ordinary_midpoint','普通'),('birkhoff_chart_midpoint','图表')]:
            selection.append((cn,label,synth['cases'][i]['methods'][method][-1]))
    rows=[]
    for a,b,r in selection:
        rows.append(f'{a} & {b} & ${r["step"]:g}$ & ${sci(r["endpoint_error"])}$ & ${r["endpoint_error_order"]:.5f}$ & ${sci(r["max_ideal_K_defect_spectral2"])}$'+r'\\')
    controls=[]
    for name,ka,kb in [('无控制','passive','passive'),('仅阻尼补偿','damping_only','damping_only'),('学习补偿／跟踪','learned','learned_tracking'),('精确补偿／跟踪','oracle','oracle_tracking')]:
        ra,rb=control['route_a'][ka],control['route_b'][kb]
        controls.append(name+' & $'+sci(ra['RMS_target_state_error'],6)+'$ & $'+sci(rb['second_half_RMS_state_error_independent_reference'],6)+'$ & $'+sci(rb['second_half_RMS_state_error_synchronous_reference'],6)+'$'+r'\\')
    budgets=[]
    for name,r in zip(['方向一','方向二'],budget['routes']):
        budgets.append(f'{name} & ${r["kappa"]:g}$ & ${sci(r["complete_normal_form_remainder_majorant"],8)}$ & ${r["image_margin"]:.10f}$ & ${sci(r["twist_determinant"],8)}$'+r'\\')
    tokens={'OLD_LABELS':str(len(inventory['labels_A'])),'NEW_LABELS':str(len(labels)),
            'MIDPOINT_EQ':labels['struct:mechanical-midpoint']['number'],
            'ELIM_EQ':labels['struct:matrix-elimination']['number'],
            'CENTRAL_EQ':labels['struct:central4']['number'],
            'METHOD_ROWS':'\n'.join(rows),'CONTROL_ROWS':'\n'.join(controls),'BUDGET_ROWS':'\n'.join(budgets)}
    source=(HERE/'report.tex.in').read_text()
    for k,v in tokens.items():source=source.replace('@@'+k+'@@',v)
    assert not re.findall(r'@@[^@]+@@',source)
    (HERE/'report.tex').write_text(source)
    provenance={'source_records':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'reproduction/new_baseline.json',ROOT/'reproduction/general_birkhoff_experiments/magnetic_method_comparison.json',ROOT/'reproduction/general_birkhoff_experiments/synthetic_method_comparison.json',ROOT/'reproduction/experiments/control_audit_summary.json',ROOT/'reproduction/route_budget/normal_form_budget_results.json']},'tokens':tokens,'English_label_source':'english/*_xr.aux','scope':'Report generation only; no numerical experiment or manuscript change'}
    (HERE/'report_provenance.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2)+'\n')
    env=os.environ.copy();env['TEXINPUTS']=str(ROOT/'texmf/tex')+'//'+os.pathsep+env.get('TEXINPUTS','')
    for i in range(2):
        p=subprocess.run(['xelatex','-no-pdf','-interaction=nonstopmode','-halt-on-error','-file-line-error','-no-shell-escape','report.tex'],cwd=HERE,env=env,capture_output=True,text=True)
        (HERE/f'build_pass_{i+1}.txt').write_text(p.stdout+p.stderr)
        if p.returncode:raise RuntimeError(p.stdout[-5000:]+p.stderr)
    log=(HERE/'report.log').read_text();bad=[x for x in log.splitlines() if re.search('undefined|Overfull|Missing character',x)]
    if bad:raise RuntimeError('\n'.join(bad))
    p=subprocess.run(['xdvipdfmx','-o','report.pdf','report.xdv'],cwd=HERE,capture_output=True,text=True)
    if p.returncode:raise RuntimeError(p.stderr)
    print(json.dumps({'report':'delivery_report/report.pdf','source_tokens':len(tokens),'layout_warnings':bad},ensure_ascii=False))

if __name__=='__main__':main()
