These are unchanged historical Material A records. Their page counts, priorities and manifests are not current fusion claims. See ../RECORD_INDEX.txt and the root README.txt.
