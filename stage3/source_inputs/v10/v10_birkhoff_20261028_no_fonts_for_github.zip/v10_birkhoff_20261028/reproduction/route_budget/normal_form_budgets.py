#!/usr/bin/env python3
"""Complete quartic-normal-form remainder majorants for A's point baseline.

This is a domain and perturbation-budget calculation, not a torus certificate.
The homological identity is checked symbolically over the exact rationals
represented by the recorded decimal parameters.  Bounds involving cosh, square
roots, eigenvalues and exponentials are evaluated in ordinary floating point.
No parameter uncertainty enclosure or theorem-specific KAM threshold is claimed.

Run from any directory:
    python3 reproduction/route_budget/normal_form_budgets.py --language en
Translate only the existing numeric display after the English review:
    python3 reproduction/route_budget/normal_form_budgets.py --render-existing --language zh
"""

from __future__ import annotations

import argparse
from decimal import Decimal
import hashlib
import json
import math
from pathlib import Path
import platform
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
RESULT = HERE / "normal_form_budget_results.json"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def calculate() -> dict:
    import sympy as sp

    started = time.perf_counter()
    baseline_path = ROOT / "reproduction/new_baseline.json"
    shared_path = ROOT / "reproduction/experiments/route_b_shared_results.json"
    baseline = json.loads(baseline_path.read_text(), parse_float=Decimal)
    shared = json.loads(shared_path.read_text())
    nu = [sp.Rational(str(v)) for v in baseline["reduced"]["nu"]]
    d = [sp.Rational(str(v)) for v in baseline["reduced"]["d"]]
    assert [float(v) for v in nu] == shared["parameters"]["nu"], "Fit and normal-form frequency versions differ."
    assert [float(v) for v in d] == shared["parameters"]["d"], "Fit and normal-form modal versions differ."
    assert shared["parameters"]["beta_artificial_true"] == 0.2, "This two-route display is for the declared beta_star=0.2 test."
    x1, x2, y1, y2 = x = sp.symbols("X1 X2 Y1 Y2", real=True)
    z1, z2, c1, c2 = zc = sp.symbols("zeta1 zeta2 chi1 chi2")
    j = sp.Matrix([[0, 0, 1, 0], [0, 0, 0, 1],
                   [-1, 0, 0, 0], [0, -1, 0, 0]])

    def grad(f):
        return sp.Matrix([sp.diff(f, xx) for xx in x])

    def bracket(f, g):
        return sp.Poly(sp.expand((grad(f).T * j * grad(g))[0]), *x).as_expr()

    def majorant(poly, radius):
        return sum(abs(cc) * radius ** sum(aa)
                   for aa, cc in sp.Poly(poly, *x).terms())

    def coefficient_record(poly):
        return [{"powers": list(aa), "coefficient_exact": str(cc),
                 "coefficient_float": float(cc)}
                for aa, cc in sp.Poly(poly, *x).terms() if cc != 0]

    h2 = (nu[0] * (x1*x1 + y1*y1) + nu[1] * (x2*x2 + y2*y2)) / 2
    h4 = -(d[0]*x1 + d[1]*x2)**4 / 24
    # Four factors of sqrt(2) give a rational factor 1/4.
    h4_complex = -(d[0]*(z1+c1) + d[1]*(z2+c2))**4 / 96
    w_complex = sp.Integer(0)
    z4_complex = sp.Integer(0)
    used_divisors = []
    for powers, cc in sp.Poly(h4_complex, *zc).terms():
        div = nu[0]*(powers[0]-powers[2]) + nu[1]*(powers[1]-powers[3])
        mon = sp.prod(v**a for v, a in zip(zc, powers))
        if powers[0] == powers[2] and powers[1] == powers[3]:
            assert div == 0
            z4_complex += cc * mon
        else:
            assert div != 0, "An additional quartic resonance needs another normal form."
            # {h2, zeta^a chi^b} = i nu.(a-b) zeta^a chi^b.
            w_complex += sp.I * cc * mon / div
            used_divisors.append(abs(div))
    polar_sub = {z1:(x1+sp.I*y1)/sp.sqrt(2), z2:(x2+sp.I*y2)/sp.sqrt(2),
                 c1:(x1-sp.I*y1)/sp.sqrt(2), c2:(x2-sp.I*y2)/sp.sqrt(2)}
    w = sp.Poly(sp.expand(w_complex.subs(polar_sub)), *x).as_expr()
    z4 = sp.Poly(sp.expand(z4_complex.subs(polar_sub)), *x).as_expr()
    assert all(cc.is_Rational for _, cc in sp.Poly(w, *x).terms())
    homological_defect = sp.Poly(sp.expand(bracket(h2, w) + h4 - z4), *x)
    assert homological_defect.is_zero
    i1, i2 = (x1*x1+y1*y1)/2, (x2*x2+y2*y2)/2
    z4_expected = -(d[0]**4*i1**2+d[1]**4*i2**2)/16 - d[0]**2*d[1]**2*i1*i2/4
    assert sp.Poly(sp.expand(z4-z4_expected), *x).is_zero
    b41 = bracket(h4, w)
    b221 = bracket(bracket(h2, w), w)
    assert all(sum(a) == 6 for a, cc in sp.Poly(b41, *x).terms() if cc != 0)
    assert all(sum(a) == 6 for a, cc in sp.Poly(b221, *x).terms() if cc != 0)
    r_out = sp.Rational(3,100)
    r_action = 2.5e-5
    i_min, i_max, rho = 1e-4, 2e-4, 0.1
    r_in = math.sqrt(2*(i_max+r_action))*math.cosh(rho)
    s_d = float(sum(abs(v) for v in d)*r_out)
    # Positive-term series avoids cancellation in cosh(s)-1-s^2/2.
    bg_partial = sum(s_d**(2*m)/math.factorial(2*m) for m in range(2,15))
    bg_tail_ratio = s_d*s_d/(31*32)
    assert bg_tail_ratio < 1
    bg_tail_bound = s_d**30/math.factorial(30)/(1-bg_tail_ratio)
    bg = bg_partial+bg_tail_bound
    tail1 = s_d**6*math.cosh(s_d)/720
    c_polar = math.cosh(rho)/math.sqrt(2*(i_min-r_action)) + r_in
    c_polar_inverse = max(2*r_in, r_in/(i_min-r_action))
    shared_fit = shared["shared_identification"]
    true_beta = shared["parameters"]["beta_artificial_true"]
    delta_beta = true_beta - shared_fit["beta_hat"]
    diagnostic_bi = shared_fit["coefficient_bound_expression_using_truth_diagnostic_only"]
    rows = []
    for kappa in [sp.Integer(1),sp.Rational(6,5)]:
        w_k = kappa*w
        v_k = j*grad(w_k)
        m_exact = max(majorant(v, r_out) for v in v_k)
        l_exact = max(sum(majorant(sp.diff(v, xx), r_out) for xx in x) for v in v_k)
        m, ell = float(m_exact), float(l_exact)
        margin = float(r_out)-r_in-m
        assert margin > 0
        bracket_one = kappa**2*majorant(b41,r_out)
        bracket_two_half = kappa**2*majorant(b221,r_out)/2
        tail = float(abs(kappa))*tail1
        remainder = tail + float(bracket_one) + float(bracket_two_half)
        a = -kappa/8*sp.Matrix([[d[0]**4,2*d[0]**2*d[1]**2],
                                [2*d[0]**2*d[1]**2,d[1]**4]])
        det_a = a.det()
        assert det_a == -3*kappa**2*d[0]**4*d[1]**4/64
        eig_low = float((a[0,0]+a[1,1])/2) - math.sqrt(float(((a[0,0]-a[1,1])/2)**2+a[0,1]**2))
        eig_high = float((a[0,0]+a[1,1])/2) + math.sqrt(float(((a[0,0]-a[1,1])/2)**2+a[0,1]**2))
        a_inv = a.inv()
        theta = max(float(sum(abs(a[ii,jj]) for jj in range(2))) for ii in range(2))
        iota = 1/max(float(sum(abs(a_inv[ii,jj]) for jj in range(2))) for ii in range(2))
        rows.append({
            "route":"A_compensation" if kappa==1 else "B_learned_reference",
            "kappa":float(kappa),
            "chart":"Phi_W4_kappa_time1 composed with positive-action polar map",
            "m_velocity_majorant":m,"m_velocity_majorant_exact":str(m_exact),
            "ell_derivative_majorant":ell,"ell_derivative_majorant_exact":str(l_exact),
            "image_margin":margin,
            "flow_derivative_bound":math.exp(ell),
            "flow_inverse_derivative_bound":math.exp(ell),
            "full_chart_derivative_bound":math.exp(ell)*c_polar,
            "local_inverse_chart_derivative_bound":math.exp(ell)*c_polar_inverse,
            "original_tail_bound":tail,
            "bracket_h4_W_bound":float(bracket_one),
            "half_double_bracket_h2_W_W_bound":float(bracket_two_half),
            "complete_normal_form_remainder_majorant":remainder,
            "twist_matrix":[[float(a[ii,jj]) for jj in range(2)] for ii in range(2)],
            "twist_determinant":float(det_a),
            "twist_sigma_min":min(abs(eig_low),abs(eig_high)),
            "twist_infinity_lower_iota":iota,"twist_infinity_upper_Theta":theta,
            "budget_symbolic":"Rbar + B_g*b_beta, conditional on |beta_star-beta_hat|<=b_beta",
            "learning_term_using_synthetic_truth_only":abs(delta_beta)*bg,
            "energy_budget_using_synthetic_truth_only":remainder+abs(delta_beta)*bg,
            "learning_term_using_truth_based_bI_diagnostic_only":diagnostic_bi*bg,
            "energy_budget_using_truth_based_bI_diagnostic_only":remainder+diagnostic_bi*bg,
            "KAM_threshold_evaluated":False,
            "C3_C4_evaluated":False,
        })
    main_initial = shared["prediction"]["initial_state"]
    max_initial = max(abs(v) for v in main_initial)
    return {
        "schema_version":1,
        "scope":"Separate complete quartic-normal-form remainder majorants on a declared auxiliary complex domain; not a finite-amplitude KAM certificate.",
        "baseline_file":"reproduction/new_baseline.json",
        "baseline_sha256":digest(baseline_path),
        "shared_fit_file":"reproduction/experiments/route_b_shared_results.json",
        "shared_fit_sha256":digest(shared_path),
        "environment":{"python":sys.version,"platform":platform.platform(),"sympy":sp.__version__},
        "parameters":{"nu":[float(v) for v in nu],"d":[float(v) for v in d],
                       "nu_exact":[str(v) for v in nu],"d_exact":[str(v) for v in d]},
        "domain":{"I_min":i_min,"I_max":i_max,"complex_action_radius":r_action,
                  "units":"dimensionless balanced phase coordinates and dimensionless actions",
                  "angle_strip_width":rho,"physical_complex_outer_radius":float(r_out),
                  "polar_image_radius":r_in,"shared_s_d":s_d,
                  "polar_derivative_bound":c_polar,"polar_inverse_derivative_bound":c_polar_inverse,
                  "definition":"dist(I_j,[I_min,I_max])<complex_action_radius; |Im phi_j|<angle_strip_width",
                  "reason":"Positive action margin makes sqrt analytic; the verified velocity majorant leaves room for both time-one normal-form flows.",
                  "main_control_initial_max_abs_coordinate":max_initial,
                  "covers_main_control_initial_state":max_initial<float(r_out)},
        "symbolic_checks":{"homological_identity_exact":True,"quartic_average_exact":True,
                           "brackets_homogeneous_degree_six":True,
                           "twist_determinant_identity_exact":True,
                           "minimum_used_quartic_divisor":float(min(used_divisors))},
        "polynomials_at_kappa_one":{"W4":coefficient_record(w),"Z4":coefficient_record(z4),
                                   "bracket_h4_W4":coefficient_record(b41),
                                   "double_bracket_h2_W4_W4":coefficient_record(b221)},
        "shared_learning":{"B_g_majorant":bg,"B_g_positive_series_tail_bound":bg_tail_bound,
                           "B_g_evaluation":"Positive terms of degree 4 through 28 plus a geometric upper bound starting with degree 30; ordinary floating-point evaluation.",
                           "delta_beta_synthetic_truth":delta_beta,
                           "truth_based_bI_diagnostic":diagnostic_bi,
                           "independent_rigorous_observation_defect_available":False,
                           "conditional_budget":"b_R_A,b_R_B <= B_g*b_beta because both chart images lie in U_outer",
                           "requires_common_complex_image_domain":True},
        "routes":rows,
        "verification_status":"symbolic assertions and stated numerical domain-margin checks passed",
        "numeric_bound_status":"Ordinary floating-point evaluations of analytic coefficient majorants; not directed-rounding interval enclosures.",
        "limitations":["No theorem-dependent delta0 or C3/C4 evaluated.",
                       "No full Diophantine certificate or a-posteriori invariant torus embedding.",
                       "The auxiliary analytic domain does not cover the initial positions of the control experiment.",
                       "Recorded decimal model parameters are point values, not validated uncertainty intervals.",
                       "Synthetic coefficient errors and truth-based observation-defect diagnostics are not hardware identification guarantees."],
        "elapsed_seconds":time.perf_counter()-started,
    }


def sci(value: float, digits: int = 4) -> str:
    mantissa, exponent = f"{value:.{digits-1}e}".split("e")
    return mantissa+r"\times10^{"+str(int(exponent))+"}"


def render_tables(data: dict, language: str) -> None:
    if language not in {"en","zh"}:
        return
    path = ROOT / ("english" if language=="en" else "chinese") / "sections"
    routes = data["routes"]
    bg = data["shared_learning"]["B_g_majorant"]
    rin = data["domain"]["polar_image_radius"]
    if language=="en":
        caption = "Separate normal-form bounds on the auxiliary complex domain in equation~\\eqref{sr:chosen-domain}. Values are floating-point evaluations of analytic majorants."
        sentence = ("The polar image radius is $r_{\\rm in}="+f"{rin:.8f}"+"$, and the remaining image margins are $"+
                    f"{routes[0]['image_margin']:.8f}"+"$ and $"+f"{routes[1]['image_margin']:.8f}"+
                    "$ for $\\kappa=1$ and $1.2$. Both chart images lie in the declared common outer domain under the stated margin condition. The shared feature majorant is $B_g\\simeq"+sci(bg)+"$. Define $\\overline\\epsilon_A=\\overline R_1+B_gb_\\beta$ and $\\overline\\epsilon_B=\\overline R_{1.2}+B_gb_\\beta$, so that $\\epsilon_s\\le\\overline\\epsilon_s$. Their numerical evaluations are\n")
        diag = ("For orientation, substituting the recorded truth-based coefficient discrepancy gives energy-budget diagnostics $"+
                sci(routes[0]["energy_budget_using_synthetic_truth_only"])+"$ and $"+
                sci(routes[1]["energy_budget_using_synthetic_truth_only"])+
                "$ on this auxiliary domain. These substitutions use synthetic truth and do not validate the independent observation-error premise.\n")
        main = ("For the recorded point model, $\\det A_{1.2}\\simeq"+sci(routes[1]["twist_determinant"])+
                "$ and $\\sigma_{\\min}(A_{1.2})\\simeq"+sci(routes[1]["twist_sigma_min"])+
                "$; this is a separate algebraic check from the nominal twist. The local remainder calculation gives $\\overline R_1\\simeq"+
                sci(routes[0]["complete_normal_form_remainder_majorant"])+"$ and $\\overline R_{1.2}\\simeq"+
                sci(routes[1]["complete_normal_form_remainder_majorant"])+"$ on the auxiliary domain specified in Supplement~\\ref{sr:budget-domain}.\n")
    else:
        caption = "式~\\eqref{sr:chosen-domain} 所定辅助复域上的两套正规形界。表中数值是解析主控式的浮点评价值。"
        sentence = ("极坐标像的半径为 $r_{\\rm in}="+f"{rin:.8f}"+"$；剩余像域余量分别为 $"+
                    f"{routes[0]['image_margin']:.8f}"+"$ 和 $"+f"{routes[1]['image_margin']:.8f}"+
                    "$，对应 $\\kappa=1$ 和 $1.2$。在上述余量条件下，两张坐标图的像均包含在所定共同外域中。共用特征主控量为 $B_g\\simeq"+sci(bg)+"$。定义 $\\overline\\epsilon_A=\\overline R_1+B_gb_\\beta$ 和 $\\overline\\epsilon_B=\\overline R_{1.2}+B_gb_\\beta$，则有 $\\epsilon_s\\le\\overline\\epsilon_s$。它们的数值评价为\n")
        diag = ("作为数值参照，代入记录中的合成真值系数差后，这个辅助域上的能量预算诊断值分别为 $"+
                sci(routes[0]["energy_budget_using_synthetic_truth_only"])+"$ 和 $"+
                sci(routes[1]["energy_budget_using_synthetic_truth_only"])+
                "$。这些代入使用了合成真值，并未验证独立观测误差前提。\n")
        main = ("对于记录的参数点模型，$\\det A_{1.2}\\simeq"+sci(routes[1]["twist_determinant"])+
                "$，$\\sigma_{\\min}(A_{1.2})\\simeq"+sci(routes[1]["twist_sigma_min"])+
                "$；这是与标称扭转矩阵分开的代数检查。在补充材料~\\ref{sr:budget-domain} 指定的辅助域上，局部余项计算给出 $\\overline R_1\\simeq"+
                sci(routes[0]["complete_normal_form_remainder_majorant"])+"$ 和 $\\overline R_{1.2}\\simeq"+
                sci(routes[1]["complete_normal_form_remainder_majorant"])+"$。\n")
    table = "% Generated from normal_form_budget_results.json; no independent translated numbers.\n"
    table += "\\begin{table*}[t]\n\\centering\\small\n\\caption{"+caption+"}\n\\label{sr:budget-table}\n"
    table += "\\begin{tabular}{rrrrrr}\n\\toprule\n$\\kappa$ & $m_\\kappa$ & $\\ell_\\kappa$ & $\\overline R_\\kappa$ & $\\det A_\\kappa$ & $\\sigma_{\\min}(A_\\kappa)$\\\\\n\\midrule\n"
    for row in routes:
        vals = [f"{row['kappa']:g}"]+[sci(row[key]) for key in ["m_velocity_majorant","ell_derivative_majorant","complete_normal_form_remainder_majorant","twist_determinant","twist_sigma_min"]]
        table += " & ".join("$"+v+"$" for v in vals)+r"\\"+"\n"
    table += "\\bottomrule\n\\end{tabular}\n\\end{table*}\n\n"+sentence
    table += "\\begin{equation}\\label{sr:evaluated-budgets}\n\\begin{aligned}\n"
    table += " \\overline\\epsilon_A&\\simeq "+sci(routes[0]["complete_normal_form_remainder_majorant"])+"+"+sci(bg)+"b_\\beta,\\\\\n"
    table += " \\overline\\epsilon_B&\\simeq "+sci(routes[1]["complete_normal_form_remainder_majorant"])+"+"+sci(bg)+"b_\\beta.\n"
    table += "\\end{aligned}\n\\end{equation}\n"+diag
    (path/"route_budget_table.tex").write_text(table)
    (path/"route_budget_main_values.tex").write_text("% Generated from the shared numerical result.\n"+main)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--render-existing", action="store_true")
    parser.add_argument("--language", choices=["none","en","zh"], default="none")
    args = parser.parse_args()
    if args.render_existing:
        data = json.loads(RESULT.read_text())
    else:
        data = calculate()
        RESULT.write_text(json.dumps(data,indent=2,ensure_ascii=False)+"\n")
    render_tables(data,args.language)
    print(json.dumps({"result":str(RESULT.relative_to(ROOT)),"status":data["verification_status"],
                      "language":args.language,"new_calculation":not args.render_existing,
                      "KAM_threshold_certified":False},ensure_ascii=False))


if __name__ == "__main__":
    main()
