Two-route normal-form budget calculation

Inputs
  ../new_baseline.json: material A's recorded point parameters, unchanged.
  ../experiments/route_b_shared_results.json: the shared frozen identification;
  its synthetic-truth discrepancy is reported only as a numerical diagnostic.

Run from the project root, with Python 3 and SymPy installed:
  python3 reproduction/route_budget/run_all.py --language en

Output
  normal_form_budget_results.json
  english/sections/route_budget_table.tex
  english/sections/route_budget_main_values.tex

The program solves the finite quartic homological equation using exact rational
representations of the recorded decimal nu and d coefficients. It verifies the
complete quartic average, the homological identity, the degree-six brackets and
the determinant identity. The complete transformed remainder is bounded using
an exact integral identity along the quartic generating flow; no higher Lie
terms are discarded. The stated common complex domain has positive action and
flow-image margins for both kappa=1 and kappa=1.2.

This calculation is not a time integration experiment. Its auxiliary complex
domain is a declared analytical design choice and does not contain the control
test's initial positions. Values involving square roots, cosh, eigenvalues and
exponentials are evaluated in ordinary floating point. They are not outward-
rounded enclosures for physical parameter uncertainties.

The output keeps the two normal-form remainders, twists, chart bounds and
learning-error budgets separate. C3, C4, the KAM theorem constant delta0, the
all-integer Diophantine condition and an invariant-torus embedding are not
certified. No finite-amplitude KAM existence claim follows from this script.

After the English review, the Chinese numeric display can be generated from
the same JSON without rerunning or independently rounding the calculation:
  python3 reproduction/route_budget/run_all.py --render-existing --language zh
