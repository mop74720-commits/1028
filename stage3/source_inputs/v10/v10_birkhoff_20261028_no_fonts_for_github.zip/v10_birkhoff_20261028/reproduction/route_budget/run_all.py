#!/usr/bin/env python3
"""Public entry point for the two-route analytic-budget calculation."""
from normal_form_budgets import main

if __name__ == "__main__":
    main()
