"""Verify the frozen shared baseline and regenerate all verification suites.

This reproduces recorded numerical experiments, not hardware or a KAM certificate.
"""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
for relative in (
    'verify_baseline.py',
    'experiments/run_all.py',
    'framework_experiments/run_all.py',
    'general_birkhoff_experiments/run_all.py',
    'route_budget/run_all.py',
):
    print(f'Running {relative}', flush=True)
    subprocess.run([sys.executable, str(root / relative)], cwd=root, check=True)
