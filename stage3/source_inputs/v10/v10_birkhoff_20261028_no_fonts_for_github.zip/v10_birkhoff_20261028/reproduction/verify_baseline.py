#!/usr/bin/env python3
"""Recompute the Material-A FE baseline without replacing its frozen JSON.

The original self-contained FE script is copied verbatim to a temporary folder.
It runs its own assertions and writes a fresh candidate there.  All numerical
leaves, parameter fields and model descriptions are compared with Material A;
only environment metadata and roundoff-level diagnostics are treated separately.
The official new_baseline.json is never written by this wrapper.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
EXPECTED_SHA = "2bac37b2f4444efc6a0ba742139fbf0b35e268e9f4f3597ba13a0793bc2049ac"


def main() -> None:
    baseline = ROOT / "new_baseline.json"
    frozen_bytes = baseline.read_bytes()
    assert hashlib.sha256(frozen_bytes).hexdigest() == EXPECTED_SHA
    original = json.loads(frozen_bytes)
    script = ROOT / "reproduce_baseline.py"
    env = os.environ.copy()
    env.update(OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1")
    with tempfile.TemporaryDirectory(prefix="v10_frozen_baseline_") as tmp:
        copied = Path(tmp) / script.name
        shutil.copy2(script, copied)
        run = subprocess.run([sys.executable, str(copied)], cwd=tmp, env=env,
                             check=True, capture_output=True, text=True)
        candidate_bytes = (Path(tmp) / "new_baseline.json").read_bytes()
        candidate = json.loads(candidate_bytes)
    checks, differences = [], []

    def compare(a, b, path=""):
        if path == "environment":
            return
        if isinstance(a, dict):
            assert a.keys() == b.keys(), path
            for key in a:
                compare(a[key], b[key], f"{path}.{key}".lstrip("."))
        elif isinstance(a, list):
            assert len(a) == len(b), path
            for i, (aa, bb) in enumerate(zip(a, b)):
                compare(aa, bb, f"{path}[{i}]")
        elif isinstance(a, (int, float)) and not isinstance(a, bool):
            # Exact source parameters; strict relative check for tiny physical
            # quantities; modest FE roundoff tolerance for derived modal data.
            if path.startswith("parameters."):
                rtol, atol = 0.0, 0.0
            elif path.startswith("properties."):
                rtol, atol = 1e-12, 0.0
            elif "error" in path or "change" in path or "residual" in path:
                # Diagnostic near-zero differences are absolute quantities;
                # a roundoff residual need not reproduce relatively. The
                # original FE script separately checks its own invariants.
                rtol, atol = 1e-6, 2e-9
            else:
                rtol, atol = 2e-8, 2e-10
            error = abs(a-b)
            limit = atol + rtol*abs(a)
            checks.append({"path": path, "absolute_difference": error,
                           "relative_tolerance": rtol, "absolute_tolerance": atol,
                           "passed": error <= limit})
            if error > limit:
                differences.append({"path": path, "baseline": a, "recomputed": b,
                                    "difference": error, "allowed": limit})
        else:
            assert a == b, path

    compare(original, candidate)
    assert baseline.read_bytes() == frozen_bytes
    report = {
        "status": "passed" if not differences else "failed",
        "executed_utc": datetime.now(timezone.utc).isoformat(),
        "purpose": "Independent rerun of A's original FE script; no physical baseline replacement",
        "baseline_path": "reproduction/new_baseline.json",
        "baseline_sha256": EXPECTED_SHA,
        "candidate_sha256": hashlib.sha256(candidate_bytes).hexdigest(),
        "script_sha256": hashlib.sha256(script.read_bytes()).hexdigest(),
        "original_environment": original["environment"],
        "recomputed_environment": candidate["environment"],
        "original_script_assertions": "passed",
        "numerical_leaves_compared": len(checks),
        "checks": checks,
        "differences_outside_tolerance": differences,
        "baseline_bytes_unchanged": True,
        "interpretation": "Floating-point reproduction, not interval certification or device validation"
    }
    destination = ROOT / "baseline_reverification.json"
    destination.write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False)+"\n")
    print(json.dumps({"output": str(destination), "status": report["status"],
                      "numerical_leaves_compared": len(checks), "differences": differences,
                      "baseline_bytes_unchanged": True}, ensure_ascii=False))
    assert not differences, "Material-A FE reproduction differs beyond the declared tolerances"


if __name__ == "__main__":
    main()
