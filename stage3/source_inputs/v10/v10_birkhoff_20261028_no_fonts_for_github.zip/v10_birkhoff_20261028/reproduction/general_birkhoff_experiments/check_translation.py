"""Read-only bilingual numerical equivalence checks; writes only a QA report."""
from pathlib import Path
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
NAMES = ("analysis.tex", "supp_experiments.tex",
         "general_birkhoff_results.tex", "supp_general_experiments.tex")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def matches(pattern, text):
    return [m.group() for m in re.finditer(pattern, text, re.S)]


def check(write_report=True):
    freeze = json.loads((PROJECT/"provenance/english_master_freeze.json").read_text())
    protected = {name: sha(PROJECT/name) == digest
                 for name, digest in freeze["files"].items()}
    assert all(protected.values()), "A frozen English source changed"
    inline = r"(?<!\\)\$(?:\\.|[^$])*?(?<!\\)\$"
    extractors = {
        "display_math_exact": lambda s: matches(r"\\begin\{(equation\*?|align\*?)\}.*?\\end\{\1\}", s),
        "inline_math_exact": lambda s: matches(inline, s),
        "references_exact": lambda s: matches(r"\\(?:label|ref|eqref|cite[tp]?)\{[^}]*\}", s),
        "environment_order_exact": lambda s: matches(r"\\(?:begin|end)\{[^}]*\}", s),
        "verbatim_exact": lambda s: matches(r"\\begin\{verbatim\}.*?\\end\{verbatim\}", s),
        # Require digits after a decimal point: a prose period in 'DOP853.'
        # is punctuation, not a different numerical value from Chinese DOP853。
        "numeric_tokens_in_order": lambda s: matches(r"[+-]?(?:\d+\.\d+|\.\d+|\d+)", s),
        # The Chinese column requires this long directory to be breakable.
        # Normalize only that approved typography change; the path itself and
        # all other code/input tokens must still agree exactly.
        "code_and_input_paths_layout_normalized": lambda s: matches(
            r"\\(?:input|texttt|path)\{[^}]*\}",
            s.replace(r"\path{reproduction/general_birkhoff_experiments}",
                      r"\texttt{reproduction/general\_birkhoff\_experiments}")),
        "figure_paths_exact": lambda s: matches(r"\\includegraphics(?:\[[^]]*\])?\{[^}]*\}", s),
        "paragraph_math_exact": lambda s: [matches(inline, p) for p in re.split(r"\n\s*\n", s)],
    }
    sections = {}
    for name in NAMES:
        en_path = PROJECT/"english/sections"/name
        zh_path = PROJECT/"chinese/sections"/name
        en, zh = en_path.read_text(), zh_path.read_text()
        comparisons = {}
        for kind, extract in extractors.items():
            e, z = extract(en), extract(zh)
            comparisons[kind] = {"identical": e == z,
                                 "english_count": len(e), "chinese_count": len(z)}
            assert e == z, (name, kind)
        assert not re.search(r"@@[A-Z_]+@@|@DISPLAY\d+@", zh), name
        sections[name] = {"english_sha256": sha(en_path), "chinese_sha256": sha(zh_path),
                          "checks": comparisons}
    en_fig = json.loads((PROJECT/"reproduction/framework_experiments/figure_data_en.json").read_text())
    zh_fig = json.loads((PROJECT/"reproduction/framework_experiments/figure_data_zh.json").read_text())
    assert en_fig == zh_fig
    record = {"status": "passed", "scope": "Four complete numerical TeX inputs; preserved material-A Chinese plus complete new general-Birkhoff numerical translations.",
              "sections": sections, "frozen_english_files_unchanged": protected,
              "english_files_checked": len(protected),
              "four_existing_figure_data_records_equal": True,
              "figures_written_or_rendered_by_this_check": False,
              "numerical_experiments_run_by_this_check": False,
              "numeric_token_convention": "Require a digit after a decimal point so that the sentence period in English DOP853. is not treated as part of a number.",
              "layout_scope": "Root compiles the Chinese PDFs; actual page visual QA is a separate step."}
    if write_report:
        (PROJECT/"reviews/fusion_numerics_translation_checks.json").write_text(
            json.dumps(record, ensure_ascii=False, indent=2)+"\n")
    return record


if __name__ == "__main__":
    record = check()
    print(json.dumps({"status": record["status"], "sections_checked": list(record["sections"]),
                      "english_files_unchanged": record["english_files_checked"]}, ensure_ascii=False, indent=2))
