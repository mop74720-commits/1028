"""Rebuild this revision's four Chinese numerical inputs from local sources.

The two existing material-A Chinese chapters retain their original prose with
the recorded local integration changes. Their templates are pinned to the
reviewed English versions. The two added inputs read the completed JSON through
build_assets.py --language zh. English sources, figures and experiment results
are never written. No numerical experiment is run.
"""
from pathlib import Path
import hashlib
import json

from build_assets import main as render_added
from check_translation import check

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]


def main():
    manifest = json.loads((HERE/"preserved_chinese_templates.json").read_text())
    for record in manifest["files"]:
        english = PROJECT/record["english_source"]
        assert hashlib.sha256(english.read_bytes()).hexdigest() == record["english_sha256"], record["english_source"]
        template = PROJECT/record["chinese_template"]
        target = PROJECT/record["chinese_output"]
        target.write_text(template.read_text())
    render_added("zh")
    report = check()
    print(json.dumps({"status": report["status"], "rebuilt_chinese_inputs": list(report["sections"]),
                      "english_and_figures_written": False, "experiments_run": False},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
