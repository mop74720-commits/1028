"""Fill the two added numerical inputs from completed JSON.

Use --language zh to render Chinese only; this does not write frozen English
sources, English provenance, experiment results, figures or the English handoff.
"""
from pathlib import Path
import argparse
import hashlib
import json

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
METHODS = {"ordinary_midpoint": "Ordinary", "weighted_midpoint": "Weighted", "chart_midpoint": "Chart", "central4": "Central4", "birkhoff_chart_midpoint": "Chart"}
CASE_NAMES = {"uncompensated_true_plant": "M: plant", "fixed_error_closed_field": "M: fixed error", "autonomous_conservative_h0": "M: $h_0$", "uncontrolled": "S: uncontrolled", "controlled": "S: controlled"}
METHODS_ZH = {"ordinary_midpoint": "普通", "weighted_midpoint": "加权", "chart_midpoint": "图表", "central4": "Central4", "birkhoff_chart_midpoint": "图表"}
CASE_NAMES_ZH = {"uncompensated_true_plant": "M：受控对象", "fixed_error_closed_field": "M：固定误差", "autonomous_conservative_h0": "M：$h_0$", "uncontrolled": "S：无控制", "controlled": "S：受控"}


def sci(value, digits=3):
    if value == 0:
        return "0"
    a, b = f"{value:.{digits}e}".split("e")
    return a+r"\times10^{"+str(int(b))+"}"


def residual(row):
    for key in ["max_linear_chart_increment_residual_inf", "max_chart_increment_residual_inf", "max_increment_residual_inf"]:
        if row.get(key) is not None:
            return row[key]
    raise KeyError("No applicable increment residual")


def fine_rows(groups):
    result = []
    for kind, case in groups:
        for method, rows in case["methods"].items():
            row = rows[-1]
            result.append((kind, case, method, row))
    return result


def table_rows(records, costs=False, language="en"):
    names = CASE_NAMES_ZH if language == "zh" else CASE_NAMES
    methods = METHODS_ZH if language == "zh" else METHODS
    lines = []
    for kind, case, method, row in records:
        if costs:
            c = row["cost"]
            op = row["required_setup_operation_counts"]
            values = [names[case["name"]], methods[method], f"${row['step']:g}$", f"${1000*c['median_cold_total_seconds']:.3f}$", f"${1000*c['median_required_setup_seconds']:.3f}$", f"${1000*c['median_warm_cached_advance_seconds']:.3f}$", f"${op['expm']}/{op['sqrtm']}/{op['Sylvester']}$"]
        else:
            values = [names[case["name"]], methods[method], f"${row['step']:g}$", "$"+sci(row["endpoint_error"])+"$", f"${row['endpoint_error_order']:.5f}$", "$"+sci(row["max_ideal_K_defect_spectral2"])+"$", "$"+sci(residual(row))+"$"]
        lines.append(" & ".join(values)+r" \\")
    return "\n".join(lines)


def table(label, caption, head, rows):
    return "\n".join([r"\begin{table*}[t]", r"\centering\small", r"\setlength{\tabcolsep}{4pt}", r"\caption{"+caption+"}", r"\label{"+label+"}", r"\begin{tabular}{llccccc}", r"\toprule", head+r"\\", r"\midrule", rows, r"\bottomrule", r"\end{tabular}", r"\end{table*}"])


def main(language="en"):
    assert language in ("en", "zh")
    paths = [HERE/"magnetic_method_comparison.json", HERE/"synthetic_method_comparison.json"]
    magnetic, synthetic = [json.loads(p.read_text()) for p in paths]
    assert all(x["status"] == "all assertions passed" for x in [magnetic, synthetic])
    records = fine_rows([("magnetic", c) for c in magnetic["cases"]]+[("synthetic", c) for c in synthetic["cases"]])
    selected = [x for x in records if x[1]["name"] in ["uncompensated_true_plant", "uncontrolled", "controlled"] or x[2] == "central4"]
    equivalence = max(r["maximum_weighted_chart_trajectory_difference"] for c in magnetic["cases"] for r in c["same_chart_specialization_check"])
    ordinary_orders = [c["methods"]["ordinary_midpoint"][-1]["endpoint_error_order"] for c in magnetic["cases"]+synthetic["cases"]]
    central_order = magnetic["cases"][-1]["methods"]["central4"][-1]["endpoint_error_order"]
    old_defect = synthetic["cases"][-1]["methods"]["birkhoff_chart_midpoint"][-1]["max_ideal_defect_against_uncontrolled_K_spectral2"]
    new_defect = synthetic["cases"][-1]["methods"]["birkhoff_chart_midpoint"][-1]["max_ideal_K_defect_spectral2"]
    main_result = (
        "The independently implemented proportional chart and weighted trajectories\n"
        "agree to at most $"+sci(equivalence)+"$ over all tested grids.\n"
        "The final ordinary-midpoint endpoint orders range from $"+f"{min(ordinary_orders):.5f}"+"$\n"
        "to $"+f"{max(ordinary_orders):.5f}"+"$; the conservative Central4 order is $"+f"{central_order:.5f}"+"$.\n"
        "The chart preserves its specified ideal structure to rounding-scale\n"
        "defects, whereas ordinary midpoint has a nonzero defect for the\n"
        "damped cases. Table~\\ref{gn:comparison-table} gives representative\n"
        "finest-grid results; full series and costs are retained in the supplement\n"
        "and JSON. For the controlled nonproportional example, the finest-grid\n"
        "chart defect is $"+sci(new_defect)+"$ against $\\mathcal K_u$ but $"+sci(old_defect)+"$\n"
        "against the uncontrolled $\\mathcal K$. Thus rebuilding the closed-loop\n"
        "structure has a testable consequence; it is not a claim that the\n"
        "original structure survives arbitrary feedback.\n\n")
    head = r"Object & Method & $\Delta$ & Endpoint error & Order & Max. $\mathcal K$ defect & Increment residual"
    cap = r"Same-object method comparisons on the finest tested grid. M denotes the new-baseline magnetic model with $T=4$; S denotes the independent dimensionless synthetic model with $T=2$. Errors are endpoint Euclidean norms and orders use the last halving. The residual is the infinity norm of each method's actual increment equation, in chart coordinates for chart methods; it is not an interchangeable physical-unit quantity."
    main_result += table("gn:comparison-table", cap, head, table_rows(selected))
    control = synthetic["control_comparison"]
    supp_result = table("gsn:all-fine", "Finest-grid results for all added comparisons. M: plant has $(\\kappa,\\gamma)=(1.2,0.05)$, M: fixed error has $(1.02,0.01)$, and M: $h_0$ has $(1,0)$. The full step series, maximum-grid errors and their separate orders remain in the two JSON records. Increment residuals follow the coordinate conventions stated in the text.", head, table_rows(records))
    supp_result += "\n\n"+table("gsn:cost", "Measured finest-grid wall times in milliseconds; medians of three repetitions in this process. Cold includes required per-grid preparation and advance; warm reuses the explicitly constructed cache. The final column counts required matrix exponentials/principal square roots/Sylvester solves per cold preparation. Reference and diagnostic costs are excluded. These are implementation measurements, not general performance claims.", r"Object & Method & $\Delta$ & Cold (ms) & Setup (ms) & Warm (ms) & exp/sqrt/Sylv", table_rows(records, True))
    supp_result += ("\n\nFor the same exact controlled target, the synthetic uncontrolled and\n"
        "controlled state RMS values are $"+sci(control["uncontrolled_RMS_to_target"], 5)+"$ and $"+sci(control["controlled_RMS_to_target"], 5)+"$,\n"
        "respectively. The peak synthetic generalized-force norm is $"+sci(control["maximum_generalized_control_norm"], 5)+"$,\n"
        "and direct substitution of the control into the original mechanical\n"
        "field differs from the stated closed field by at most $"+sci(control["maximum_control_substitution_identity_error"])+"$.\n"
        "These dimensionless values have no magnetic-hardware interpretation.\n")
    if language == "zh":
        main_result = (
            "独立实现的比例阻尼图表轨迹与加权轨迹在全部测试网格上的最大差异为 $"+sci(equivalence)+"$。\n"
            "普通中点法的最终终点误差观测阶介于 $"+f"{min(ordinary_orders):.5f}"+"$ 与 $"+f"{max(ordinary_orders):.5f}"+"$ 之间；保守 Central4 的观测阶为 $"+f"{central_order:.5f}"+"$。\n"
            "图表法所指定理想结构的缺陷处于舍入误差量级，而普通中点法在含阻尼情形下具有非零缺陷。表~\\ref{gn:comparison-table} 给出最细网格的代表结果；完整序列与成本保留在补充材料和 JSON 中。对于受控非比例阻尼算例，最细网格上图表法的缺陷为 $"+sci(new_defect)+"$（相对 $\\mathcal K_u$），而相对无控制模型则为 $"+sci(old_defect)+"$（相对 $\\mathcal K$）。因此，为实际闭环重新构造结构会产生可检验的差别；这并不声称任意反馈均保留原有结构。\n\n")
        head = r"对象 & 方法 & $\Delta$ & 终点误差 & 观测阶 & 最大 $\mathcal K$ 缺陷 & 增量残差"
        cap = r"最细测试网格上针对同一对象的方法比较。M 表示 $T=4$ 的新基准磁模型；S 表示 $T=2$ 的独立无量纲合成模型。误差为终点欧氏范数，观测阶由最后一次步长减半计算。残差为各方法实际增量方程的无穷范数，图表法采用图表坐标；这些残差不是可以互换的同一物理单位量。"
        main_result += table("gn:comparison-table", cap, head, table_rows(selected, language="zh"))
        supp_result = table("gsn:all-fine", r"全部附加比较的最细网格结果。M：受控对象采用 $(\kappa,\gamma)=(1.2,0.05)$，M：固定误差采用 $(1.02,0.01)$，M：$h_0$ 采用 $(1,0)$。完整步长序列、全网格最大误差及其各自的观测阶保留在两份 JSON 记录中。增量残差遵循文中所述的坐标约定。", head, table_rows(records, language="zh"))
        supp_result += "\n\n"+table("gsn:cost", "最细网格的实测墙钟时间，单位为毫秒；数值为同一进程内三次重复的中位数。冷启动包含每个网格必需的准备及推进；热启动复用显式构建的缓存。末列统计每次冷启动准备中所需的矩阵指数／主平方根／Sylvester 求解次数。排除参考与诊断的成本。这些是当前实现的测量结果，并非一般性能结论。", r"对象 & 方法 & $\Delta$ & 冷启动 (ms) & 准备 (ms) & 热启动 (ms) & exp/sqrt/Sylv", table_rows(records, True, language="zh"))
        supp_result += ("\n\n对于同一个精确受控目标，合成无控制组与受控组的状态 RMS 分别为 $"+sci(control["uncontrolled_RMS_to_target"], 5)+"$ 和 $"+sci(control["controlled_RMS_to_target"], 5)+"$。\n"
            "合成广义力范数的峰值为 $"+sci(control["maximum_generalized_control_norm"], 5)+"$，将控制直接代入原机械向量场后，与所声明闭环向量场的差异至多为 $"+sci(control["maximum_control_substitution_identity_error"])+"$。\n"
            "这些无量纲数值没有磁硬件含义。\n")
    target = "chinese" if language == "zh" else "english"
    for template, output, token, text in [("main_results.tex.in", "general_birkhoff_results.tex", "@@MAIN_RESULTS@@", main_result), ("supp_results.tex.in", "supp_general_experiments.tex", "@@SUPP_RESULTS@@", supp_result)]:
        if language == "zh":
            template = template.replace(".tex.in", ".zh.tex.in")
        source = (HERE/template).read_text()
        assert source.count(token) == 1
        (PROJECT/target/"sections"/output).write_text("% Generated by reproduction/general_birkhoff_experiments/build_assets.py.\n"+source.replace(token, text))
    provenance = {"status": "rendered from completed numerical records", "source_files": [{"path": str(p.relative_to(PROJECT)), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths],
        "main_and_supplement_finest_grid_records": [{"source": k, "case": c["name"], "method": m, "row": r} for k,c,m,r in records],
        "displayed_specialization_maximum": equivalence, "displayed_control": control,
        "outputs": [target+"/sections/general_birkhoff_results.tex", target+"/sections/supp_general_experiments.tex"]}
    provenance_path = "numerical_provenance_zh.json" if language == "zh" else "numerical_provenance.json"
    (HERE/provenance_path).write_text(json.dumps(provenance, ensure_ascii=False, indent=2)+"\n")
    handoff = {"new_experiments_status": "executed; all assertions passed", "baseline_unchanged": True,
        "baseline_sha256": magnetic["provenance"]["baseline_sha256"], "new_groups": [],
        "retained_not_rerun_this_revision": ["Material-A joint fit, four restoration groups and four tracking groups", "Material-A damping scan", "Material-A manufactured algebraic-defect and fixed-model-error convergence records"],
        "not_completed": ["General high-dimensional one-form/chart numerical construction", "New-parameter full CHNN training", "64-mode fixed-controller nonlinear closed-loop validation", "Independent COMSOL", "Actuator calibration and hardware/noise/saturation tests", "Validated analytic-domain and finite-amplitude KAM thresholds", "Implemented energy governor satisfying the clearance cap"]}
    for kind, source in [("magnetic", magnetic), ("synthetic", synthetic)]:
        for c in source["cases"]:
            handoff["new_groups"].append({"kind": kind, "name": c["name"], "parameter_version": magnetic["provenance"]["baseline_sha256"] if kind == "magnetic" else "material-B declared dimensionless matrices; independent of the physical baseline", "initial_state": c["initial_state"], "T": c.get("duration_tau", c.get("T")), "steps": c.get("steps_tau", c.get("steps")), "reference": c["reference"], "error_definitions": source["error_definitions"], "result_path": "reproduction/general_birkhoff_experiments/"+("magnetic" if kind == "magnetic" else "synthetic")+"_method_comparison.json", "finest_results": {m: rows[-1] for m,rows in c["methods"].items()}, "status": source["status"]})
    fe_check = PROJECT/"reproduction/baseline_reverification.json"
    if fe_check.exists():
        fe = json.loads(fe_check.read_text())
        assert fe["status"] == "passed" and fe["baseline_bytes_unchanged"]
        handoff["baseline_independently_reverified_this_revision"] = {k: fe[k] for k in ["status", "baseline_sha256", "script_sha256", "numerical_leaves_compared", "baseline_bytes_unchanged", "interpretation"]}
        handoff["baseline_independently_reverified_this_revision"]["path"] = "reproduction/baseline_reverification.json"
    if language == "en":
        (PROJECT/"reviews/fusion_numerics_handoff.json").write_text(json.dumps(handoff, ensure_ascii=False, indent=2)+"\n")
    print(json.dumps({"outputs": provenance["outputs"], "language": language, "finest_rows": len(records), "provenance": provenance_path}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--language", choices=("en", "zh"), default="en")
    main(parser.parse_args().language)
