"""Material-B variable-mass/nonproportional-drag mathematical test.

The model is an intentionally known nonlinear canonical conjugate of a
linear system. Matrix exponentials construct the specified K and an
independent reference. They do not advance the numerical state. The chart
step uses the midpoint Cayley matrix of the time-dependent transformed
Hamiltonian field. No catheter, learning, coil or KAM claim is made.
"""
import time
import numpy as np
import sympy as sp
from scipy.linalg import expm, sqrtm, solve_sylvester
from common import J, K0, I4, midpoint_step, integrate, time_method, reference_pair, errors, write_result

M0 = np.array([[1.12, .12], [.12, 1.32]])
KS = np.array([[1.05, .05], [.05, 2.05]])
C0 = np.array([[.18, .025], [.025, .37]])
CD = np.array([[.09, .009], [.009, .14]])
KP = np.diag([.05, .10])
Z0 = np.array([.25, -.18, .03, .04])
STEPS = [.2, .1, .05, .025]
DURATION = 2.


def point_map(q):
    return np.array([q[0]+.2*q[0]**3, (1+.15*q[0])*q[1]])


def point_derivative(q):
    return np.array([[1+.6*q[0]**2, 0.], [.15*q[1], 1+.15*q[0]]])


def xi(z):
    return np.r_[point_map(z[:2]), np.linalg.solve(point_derivative(z[:2]).T, z[2:])]


def inverse_xi(y):
    q1 = float(y[0])
    for corrections in range(31):
        residual = q1+.2*q1**3-y[0]
        if abs(residual) <= 5e-15:
            break
        if corrections == 30:
            raise RuntimeError("Inverse point chart failed its function-residual test")
        q1 -= residual/(1+.6*q1*q1)
    scale = 1+.15*q1
    if abs(scale) < 1e-8:
        raise ValueError("Point chart approached its excluded singular boundary")
    q = np.array([q1, y[1]/scale])
    z = np.r_[q, point_derivative(q).T@y[2:]]
    return z, corrections


def build_model(C, stiffness):
    start = time.perf_counter()
    q1, q2, p1, p2 = sp.symbols("q1 q2 p1 p2", real=True)
    z = sp.Matrix([q1, q2, p1, p2])
    q, p = z[:2, :], z[2:, :]
    Q = sp.Matrix([q1+sp.Rational(1, 5)*q1**3, (1+sp.Rational(3, 20)*q1)*q2])
    D = Q.jacobian(q)
    P = D.T.inv()*p
    mass = D.T*sp.Matrix(M0)*D
    damping = D.T*sp.Matrix(C)*D
    H = (p.T*mass.inv()*p)[0]/2+(Q.T*sp.Matrix(stiffness)*Q)[0]/2
    hp = sp.Matrix([sp.diff(H, p1), sp.diff(H, p2)])
    hq = sp.Matrix([sp.diff(H, q1), sp.diff(H, q2)])
    expression = hp.col_join(-hq-damping*hp)
    ff = sp.lambdify(tuple(z), expression, "numpy", cse=True)
    jj = sp.lambdify(tuple(z), expression.jacobian(z), "numpy", cse=True)
    dd = sp.lambdify(tuple(z), Q.col_join(P).jacobian(z), "numpy", cse=True)
    A = np.block([[np.zeros((2, 2)), np.linalg.solve(M0, np.eye(2))], [-stiffness, -C@np.linalg.solve(M0, np.eye(2))]])
    return {
        "A": A, "C": C, "stiffness": stiffness,
        "field": lambda z: np.asarray(ff(*z)).reshape(4),
        "jacobian": lambda z: np.asarray(jj(*z)),
        "Dxi": lambda z: np.asarray(dd(*z)),
        "symbolic_original_H_derivative_build_seconds": time.perf_counter()-start,
    }


def linear_K(A, t):
    S = expm(-A*t)
    return S.T@K0@S


def physical_K(model, t, z):
    d = model["Dxi"](z)
    return d.T@linear_K(model["A"], t)@d


def prepare_chart(A, h, duration, diagnostics=False):
    count = round(duration/h)
    operations = {"expm": 0, "sqrtm": 0, "Sylvester": 0, "dense_linear_solve": 0}
    checks = {"maximum_chart_congruence_defect_spectral2": 0., "maximum_transformed_Hamiltonian_defect_spectral2": 0., "maximum_square_root_imaginary_part": 0., "maximum_Sylvester_equation_residual_inf": 0., "minimum_chart_singular_value": np.inf, "maximum_Cayley_matrix_equation_residual_inf": 0.}

    def solve(Aa, b):
        operations["dense_linear_solve"] += 1
        return np.linalg.solve(Aa, b)

    def chart(t, generator):
        S = expm(-A*t)
        operations["expm"] += 1
        K = S.T@K0@S
        B = solve(K0, K)
        raw = sqrtm(B)
        operations["sqrtm"] += 1
        imag = float(np.max(np.abs(np.imag(raw))))
        if imag > 1e-10:
            raise ValueError("The tested real principal-square-root branch is unavailable")
        T = np.asarray(np.real(raw), dtype=float)
        if diagnostics:
            checks["maximum_square_root_imaginary_part"] = max(checks["maximum_square_root_imaginary_part"], imag)
            checks["maximum_chart_congruence_defect_spectral2"] = max(checks["maximum_chart_congruence_defect_spectral2"], float(np.linalg.norm(T.T@K0@T-K, 2)))
            checks["minimum_chart_singular_value"] = min(checks["minimum_chart_singular_value"], float(np.linalg.svd(T, compute_uv=False)[-1]))
        if not generator:
            return T
        Kdot = -A.T@K-K@A
        Bdot = solve(K0, Kdot)
        Tdot = solve_sylvester(T, T, Bdot)
        operations["Sylvester"] += 1
        Ti = solve(T, I4)
        L = Tdot@Ti+T@A@Ti
        if diagnostics:
            checks["maximum_Sylvester_equation_residual_inf"] = max(checks["maximum_Sylvester_equation_residual_inf"], float(np.linalg.norm(T@Tdot+Tdot@T-Bdot, np.inf)))
            checks["maximum_transformed_Hamiltonian_defect_spectral2"] = max(checks["maximum_transformed_Hamiltonian_defect_spectral2"], float(np.linalg.norm(L.T@K0+K0@L, 2)))
        return T, L

    edges = [chart(k*h, False) for k in range(count+1)]
    rows = []
    for k in range(count):
        Tm, L = chart((k+.5)*h, True)
        left, right = I4-h*L/2, I4+h*L/2
        cayley = solve(left, right)
        update = solve(edges[k+1], cayley@edges[k])
        if diagnostics:
            checks["maximum_Cayley_matrix_equation_residual_inf"] = max(checks["maximum_Cayley_matrix_equation_residual_inf"], float(np.linalg.norm(left@cayley-right, np.inf)))
        rows.append({"T0": edges[k], "T1": edges[k+1], "Tm": Tm, "L": L, "update": update})
    return {"method": "birkhoff_chart_midpoint", "h": h, "rows": rows, "checks": checks, "required_operations": operations,
            "cache": "Every endpoint/midpoint chart and Cayley update is prepared once per grid; all preparation is in the cold time. The warm time deliberately reuses this full cache."}


def prepare(method, model, h, diagnostics=False):
    if method == "birkhoff_chart_midpoint":
        return prepare_chart(model["A"], h, DURATION, diagnostics)
    return {"method": method, "h": h, "required_operations": {"expm": 0, "sqrtm": 0, "Sylvester": 0, "dense_linear_solve": 0}, "checks": {}}


def step_factory(model):
    def step(old, k, data, diagnostics):
        h = data["h"]
        if data["method"] == "ordinary_midpoint":
            return midpoint_step(old, h, model["field"], model["jacobian"], diagnostics)
        row = data["rows"][k]
        yold = xi(old)
        ynew = row["update"]@yold
        new, corrections = inverse_xi(ynew)
        stats = {"inverse_chart_Newton_corrections": corrections, "Newton_corrections": None, "increment_residual_inf": None}
        tangent = None
        if diagnostics:
            restored = xi(new)
            uold, unew = row["T0"]@yold, row["T1"]@restored
            stats["inverse_chart_residual_inf"] = np.linalg.norm(restored-ynew, np.inf)
            stats["linear_chart_increment_residual_inf"] = np.linalg.norm(unew-uold-h*row["L"]@((unew+uold)/2), np.inf)
            stats["minimum_point_chart_singular_value"] = np.linalg.svd(model["Dxi"](new), compute_uv=False)[-1]
            tangent = np.linalg.solve(model["Dxi"](new), row["update"]@model["Dxi"](old))
        return new, tangent, stats
    return step


def run(repetitions=3):
    models = {"uncontrolled": build_model(C0, KS), "controlled": build_model(CD, KS+KP)}
    cases, fine_states = [], {}
    rng = np.random.default_rng(712)
    for name, model in models.items():
        A, f = model["A"], model["field"]
        samples = Z0+.08*rng.standard_normal((8, 4))
        conjugacy = max(float(np.linalg.norm(model["Dxi"](z)@f(z)-A@xi(z))) for z in samples)
        assert conjugacy < 1e-11
        y0 = xi(Z0)
        refs, ref_protocol = reference_pair(f, Z0, DURATION)
        times_finest = np.arange(round(DURATION/min(STEPS))+1)*min(STEPS)
        exact_finest = np.array([inverse_xi(expm(A*t)@y0)[0] for t in times_finest])
        independent_difference = float(np.max(np.linalg.norm(refs[1].sol(times_finest).T-exact_finest, axis=1)))
        ref_refinement = float(np.max(np.linalg.norm(refs[1].sol(times_finest).T-refs[0].sol(times_finest).T, axis=1)))
        assert independent_difference < 1e-10
        sf = step_factory(model)
        structure = lambda t, z: physical_K(model, t, z)
        old_structure = (lambda t, z: physical_K(models["uncontrolled"], t, z)) if name == "controlled" else None
        groups = {}
        for method in ["ordinary_midpoint", "birkhoff_chart_midpoint"]:
            rows = []
            for h in STEPS:
                data = prepare(method, model, h, True)
                states, diagnostics = integrate(data, sf, Z0, h, DURATION, True, structure, old_structure)
                ref = exact_finest[::round(h/min(STEPS))]
                row = errors(states, ref, h, rows[-1] if rows else None)
                row.update(diagnostics)
                row["required_setup_operation_counts"] = data["required_operations"]
                row["chart_checks"] = data["checks"]
                row["cost"] = time_method(lambda: prepare(method, model, h, False), sf, Z0, h, DURATION, repetitions)
                row["minimum_sampled_mass_eigenvalue"] = min(float(np.linalg.eigvalsh(point_derivative(z[:2]).T@M0@point_derivative(z[:2]))[0]) for z in states)
                row["minimum_abs_point_chart_denominator"] = min(abs(1+.15*z[0]) for z in states)
                if method == "birkhoff_chart_midpoint":
                    row["max_increment_residual_inf"] = None
                    row["max_Newton_corrections"] = None
                    row["Newton_increment_note"] = "Not applicable: chart midpoint is a linear solve. Its residual and the nonlinear inverse-coordinate Newton residual/count are reported separately."
                    assert row["max_ideal_K_defect_spectral2"] < 5e-11
                    assert row["max_linear_chart_increment_residual_inf"] < 1e-12
                    assert row["max_inverse_chart_residual_inf"] < 1e-12
                rows.append(row)
                if h == min(STEPS):
                    fine_states[name, method] = states
            assert abs(rows[-1]["endpoint_error_order"]-2) < .05
            assert abs(rows[-1]["maximum_grid_error_order"]-2) < .05
            groups[method] = rows
        assert groups["ordinary_midpoint"][0]["max_ideal_K_defect_spectral2"] > 1e-8
        if name == "controlled":
            assert groups["birkhoff_chart_midpoint"][0]["max_ideal_defect_against_uncontrolled_K_spectral2"] > 1e-5
        # Independently difference the actual composed update; K is fixed by A.
        h = .1
        data = prepare_chart(A, h, h, True)
        old = Z0+.01*np.arange(4)
        new, analytic, _ = sf(old, 0, data, True)
        finite_differences = []
        for eps in [2e-4, 2e-5, 2e-6]:
            numeric = np.column_stack([(sf(old+eps*I4[j], 0, data, False)[0]-sf(old-eps*I4[j], 0, data, False)[0])/(2*eps) for j in range(4)])
            tangent_error = float(np.linalg.norm(numeric-analytic, 2))
            assert tangent_error < 2e-8
            finite_differences.append({"difference_step": eps, "finite_difference_vs_ideal_tangent_error_spectral2": tangent_error,
                "finite_difference_K_defect_spectral2": np.linalg.norm(numeric.T@structure(h, new)@numeric-structure(0., old), 2)})
        d0, d1 = data["rows"][0]["T0"]@model["Dxi"](old), data["rows"][0]["T1"]@model["Dxi"](new)
        dalpha = np.block([[J@d1, -J@d0], [d1/2, d0/2]])
        j8 = np.block([[np.zeros((4, 4)), I4], [-I4, np.zeros((4, 4))]])
        target = np.block([[structure(h, new), np.zeros((4, 4))], [np.zeros((4, 4)), -structure(0., old)]])
        endpoint_defect = float(np.linalg.norm(dalpha.T@j8@dalpha-target, 2))
        assert endpoint_defect < 5e-11
        cases.append({"name": name, "A": A, "C": model["C"], "stiffness": model["stiffness"],
            "initial_state": Z0, "T": DURATION, "steps": STEPS,
            "CM_inverse_commutator_spectral2": np.linalg.norm(model["C"]@np.linalg.inv(M0)-np.linalg.inv(M0)@model["C"], 2),
            "original_equation_conjugacy_error": conjugacy,
            "reference": {"exact": "xi^{-1}(expm(A*t)*xi(z0)); evaluated independently at each finest-grid time", "independent_original_coordinate_check": ref_protocol, "maximum_grid_exact_DOP853_difference": independent_difference, "maximum_grid_DOP853_refinement_difference": ref_refinement},
            "symbolic_original_model_build_seconds": model["symbolic_original_H_derivative_build_seconds"],
            "model_build_note": "One-off symbolic differentiation of the full original mechanical H, its Jacobian and Dxi, disclosed separately from per-grid method cost. The latent A and point map are declared inputs.",
            "methods": groups, "representative_composed_derivative_check": {"time": 0., "h": h, "state": old, "epsilon_sweep": finite_differences,
                "scope": "One step and state per synthetic case; epsilon sweep exposes differencing/rounding effects and is not a full-domain exact derivative certificate."},
            "endpoint_compatibility_defect_spectral2": endpoint_defect})
    no = fine_states["uncontrolled", "birkhoff_chart_midpoint"]
    yes = fine_states["controlled", "birkhoff_chart_midpoint"]
    ts = times_finest
    Ac = models["controlled"]["A"]
    target = np.array([inverse_xi(expm(Ac*t)@xi(Z0))[0] for t in ts])
    commands, substitution = [], []
    for z in yes:
        y = xi(z)
        u = point_derivative(z[:2]).T@((C0-CD)@np.linalg.solve(M0, y[2:])-KP@y[:2])
        commands.append(np.linalg.norm(u))
        substitution.append(np.linalg.norm(models["uncontrolled"]["field"](z)+np.r_[0., 0., u]-models["controlled"]["field"](z)))
    assert max(substitution) < 1e-11
    control = {"reference": "same exact controlled target for both groups", "initial_state": Z0, "T": DURATION, "h": min(STEPS),
        "uncontrolled_RMS_to_target": np.sqrt(np.mean(np.sum((no-target)**2, axis=1))),
        "controlled_RMS_to_target": np.sqrt(np.mean(np.sum((yes-target)**2, axis=1))),
        "maximum_generalized_control_norm": max(commands), "maximum_control_substitution_identity_error": max(substitution),
        "K_controlled_minus_uncontrolled_at_t1_z0_spectral2": np.linalg.norm(physical_K(models["controlled"], 1., Z0)-physical_K(models["uncontrolled"], 1., Z0), 2),
        "input_assumptions": "Ideal, unrestricted, fully actuated two-coordinate generalized force; no learned coefficients, magnetic decoder, measurement noise or saturation.",
        "scope": "Confirms a structure can be rebuilt for a closed loop that still has nonproportional drag; not a catheter control-performance result."}
    result = {"scope": "Artificial variable-mass, nonproportional-damping known-chart test from material B; not a physical catheter or KAM certificate.",
        "units": "All synthetic coordinates, time and matrices are dimensionless declared mathematical test values.",
        "parameters": {"M0": M0, "C0": C0, "Cd": CD, "Ks": KS, "Kp": KP},
        "point_chart": "Q1=q1+0.2*q1^3; Q2=(1+0.15*q1)*q2; P=DQ(q)^(-T)*p; xi=(Q,P)",
        "mechanical_model": "M(q)=DQ^T M0 DQ; C(q)=DQ^T C DQ; V(q)=Q^T stiffness Q/2; H_q includes every derivative of M(q)^(-1)",
        "specified_structure": "K_y(t)=exp(-A^T*t)*K0*exp(-A*t); K_z=Dxi^T*K_y*Dxi, fixed before discretization",
        "chart": "chi_t=T(t)*xi with real principal T=(K0^-1 K_y)^(1/2); Tdot by Sylvester; midpoint in transformed field L(t)=Tdot*T^-1+T*A*T^-1",
        "cases": cases, "control_comparison": control,
        "error_definitions": {"endpoint_error": "||z_N-z_ref(T)||_2", "maximum_grid_error": "max_k ||z_k-z_ref(t_k)||_2", "structure": "max_k ||Dpsi^T K(z_{k+1},t_{k+1})Dpsi-K(z_k,t_k)||_2", "solves": "Infinity residual of ordinary nonlinear increment, chart linear midpoint increment and inverse xi equation reported separately"},
        "Newton": {"ordinary_tolerance_inf": 2e-14, "ordinary_max_corrections": 12, "inverse_chart_function_tolerance": 5e-15, "inverse_chart_max_corrections": 30},
        "limitations": ["Known nonlinear conjugacy and explicit matrix-exponential K are essential to this test, not an efficient construction for arbitrary f.", "Required chart preparation is included in cold cost. Cached warm cost is disclosed separately and cannot establish a universal speed advantage.", "No proportional weighted formula or autonomous Central4 is assigned to this general nonautonomous chart problem.", "Finite-difference tangent checks and floating-point defects are implementation diagnostics, not interval enclosures or exact arithmetic certificates."],
        "status": "all assertions passed"}
    write_result("synthetic_method_comparison.json", result)
    print("G3: variable mass/nonproportional drag, old/new controlled K, residuals, references, endpoint compatibility and measured costs passed", flush=True)
    return result
