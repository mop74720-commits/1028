"""Independent chart/ordinary/weighted comparison on material A's baseline."""
import sys
import numpy as np
from common import HERE, baseline, J, K0, I4, newton, midpoint_step, integrate, time_method, reference_pair, errors, write_result

R = baseline()["reduced"]
NU = np.array(R["nu"])
N = np.diag(NU)
D = np.array(R["d"])
Z0 = np.array([.09, .08, .015, -.01])
STEPS = [.04, .02, .01, .005]
DURATION = 4.


def grad(q, kappa):
    s = D@q
    return NU*q+kappa*(np.sin(s)-s)*D


def hess(q, kappa):
    return N+kappa*(np.cos(D@q)-1)*np.outer(D, D)


def field(z, kappa, gamma):
    return np.r_[NU*z[2:], -grad(z[:2], kappa)-gamma*z[2:]]


def jac(z, kappa, gamma):
    return np.block([[np.zeros((2, 2)), N], [-hess(z[:2], kappa), -gamma*np.eye(2)]])


def prepare(method, h, duration, gamma):
    count = round(duration/h)
    if method == "chart_midpoint":
        # This is chi_t=(X,exp(gamma*t)Y), not the direct weighted equation.
        return {"method": method, "h": h, "gamma": gamma,
                "edge_scale": np.exp(gamma*np.arange(count+1)*h),
                "mid_scale": np.exp(gamma*(np.arange(count)+.5)*h),
                "required_operations": {"scalar_exponentials": 2*count+1, "expm": 0, "sqrtm": 0, "Sylvester": 0}}
    return {"method": method, "h": h, "gamma": gamma, "r": np.exp(gamma*h/2) if method == "weighted_midpoint" else None,
            "required_operations": {"scalar_exponentials": 1 if method == "weighted_midpoint" else 0, "expm": 0, "sqrtm": 0, "Sylvester": 0}}


def step_factory(kappa, gamma):
    # Existing, independently checked complete magnetic Central4 derivatives.
    # This import reads material A but does not run or rewrite any experiment.
    sys.path.insert(0, str(HERE.parent / "framework_experiments"))
    from framework_common import central4_increment, central4_increment_jacobian

    def step(old, index, data, diagnostics):
        method, h = data["method"], data["h"]
        f = lambda z: field(z, kappa, gamma)
        df = lambda z: jac(z, kappa, gamma)
        if method == "ordinary_midpoint":
            new, tangent, stats = midpoint_step(old, h, f, df, diagnostics)
        elif method == "weighted_midpoint":
            r = data["r"]
            def residual(z):
                q = (z[:2]+old[:2])/2
                return np.r_[z[:2]-old[:2]-h/2*NU*(r*z[2:]+old[2:]/r), r*z[2:]-old[2:]/r+h*grad(q, kappa)]
            def derivative(z):
                return np.block([[np.eye(2), -h*r*N/2], [h*hess((z[:2]+old[:2])/2, kappa)/2, r*np.eye(2)]])
            new, rn, corrections = newton(residual, derivative, old+h*f(old))
            stats = {"increment_residual_inf": rn, "Newton_corrections": corrections}
            tangent = None
            if diagnostics:
                ap = derivative(new)
                am = np.block([[-np.eye(2), -h*N/(2*r)], [h*hess((new[:2]+old[:2])/2, kappa)/2, -np.eye(2)/r]])
                tangent = -np.linalg.solve(ap, am)
                stats["minimum_Newton_matrix_singular_value"] = np.linalg.svd(ap, compute_uv=False)[-1]
        elif method == "chart_midpoint":
            a0, a1, am = data["edge_scale"][index], data["edge_scale"][index+1], data["mid_scale"][index]
            uold = old*np.array([1., 1., a0, a0])
            g = lambda u: np.r_[NU*u[2:]/am, -am*grad(u[:2], kappa)]
            dg = lambda u: np.block([[np.zeros((2, 2)), N/am], [-am*hess(u[:2], kappa), np.zeros((2, 2))]])
            unew, tangent_u, stats = midpoint_step(uold, h, g, dg, diagnostics)
            stats["chart_increment_residual_inf"] = stats.pop("increment_residual_inf")
            new = unew/np.array([1., 1., a1, a1])
            if diagnostics:
                stats["inverse_chart_residual_inf"] = np.linalg.norm(new*np.array([1., 1., a1, a1])-unew, np.inf)
                r = np.exp(gamma*h/2)
                pulled = np.r_[new[:2]-old[:2]-h/2*NU*(r*new[2:]+old[2:]/r), r*new[2:]-old[2:]/r+h*grad((new[:2]+old[:2])/2, kappa)]
                stats["physical_weighted_equation_residual_inf"] = np.linalg.norm(pulled, np.inf)
            tangent = None if not diagnostics else np.diag([1., 1., 1/a1, 1/a1])@tangent_u@np.diag([1., 1., a0, a0])
        elif method == "central4":
            if gamma != 0. or kappa != 1.:
                raise ValueError("Central4 is used only on the same autonomous conservative h0")
            inc = lambda z: central4_increment(z, h, kappa)
            der = lambda z: central4_increment_jacobian(z, h, kappa)
            residual = lambda z: z-old-inc((z+old)/2)
            derivative = lambda z: I4-der((z+old)/2)/2
            new, rn, corrections = newton(residual, derivative, old+inc(old))
            stats = {"increment_residual_inf": rn, "Newton_corrections": corrections}
            tangent = None
            if diagnostics:
                dd = der((new+old)/2)/2
                tangent = np.linalg.solve(I4-dd, I4+dd)
                stats["minimum_Newton_matrix_singular_value"] = np.linalg.svd(I4-dd, compute_uv=False)[-1]
        else:
            raise ValueError(method)
        if diagnostics:
            stats["ideal_exponential_conformal_defect_spectral2"] = np.linalg.norm(tangent.T@J@tangent-np.exp(-gamma*h)*J, 2)
        return new, tangent, stats
    return step


def run(repetitions=3):
    cases = []
    for name, kappa, gamma in [("uncompensated_true_plant", 1.2, .05), ("fixed_error_closed_field", 1.02, .01), ("autonomous_conservative_h0", 1., 0.)]:
        methods = ["ordinary_midpoint", "weighted_midpoint", "chart_midpoint"]
        if gamma == 0.:
            methods.append("central4")
        f = lambda z: field(z, kappa, gamma)
        refs, ref_protocol = reference_pair(f, Z0, DURATION)
        step_function = step_factory(kappa, gamma)
        structure = lambda t, z: np.exp(gamma*t)*K0
        groups, states_saved, refinement = {}, {}, 0.
        for method in methods:
            rows = []
            for h in STEPS:
                prep = lambda: prepare(method, h, DURATION, gamma)
                data = prep()
                states, diagnostics = integrate(data, step_function, Z0, h, DURATION, True, structure)
                ts = np.arange(len(states))*h
                reference = refs[1].sol(ts).T
                refinement = max(refinement, float(np.max(np.linalg.norm(reference-refs[0].sol(ts).T, axis=1))))
                row = errors(states, reference, h, rows[-1] if rows else None)
                row.update(diagnostics)
                row["required_setup_operation_counts"] = data["required_operations"]
                row["cost"] = time_method(prep, step_function, Z0, h, DURATION, repetitions)
                row["Newton_unknown_dimension"] = 4
                row["residual_coordinate"] = "chart u increment; physical weighted-equation residual also recorded" if method == "chart_midpoint" else "original-state increment equation"
                rows.append(row)
                states_saved[method, h] = states
            expected = 4 if method == "central4" else 2
            assert abs(rows[-1]["endpoint_error_order"]-expected) < .12
            assert abs(rows[-1]["maximum_grid_error_order"]-expected) < .12
            if method != "ordinary_midpoint" or gamma == 0.:
                assert max(r["max_ideal_K_defect_spectral2"] for r in rows) < 5e-12
            groups[method] = rows
        equivalence = []
        for h in STEPS:
            ec = float(np.max(np.linalg.norm(states_saved["weighted_midpoint", h]-states_saved["chart_midpoint", h], axis=1)))
            assert ec < 2e-10
            row = {"step": h, "maximum_weighted_chart_trajectory_difference": ec}
            if gamma == 0.:
                eo = float(np.max(np.linalg.norm(states_saved["ordinary_midpoint", h]-states_saved["weighted_midpoint", h], axis=1)))
                assert eo < 2e-10
                row["maximum_ordinary_weighted_trajectory_difference"] = eo
            equivalence.append(row)
        if gamma:
            assert groups["ordinary_midpoint"][0]["max_ideal_K_defect_spectral2"] > 1e-10
        assert refinement < min(r["endpoint_error"] for rows in groups.values() for r in rows)*.01
        derivative_checks = []
        for method in methods:
            check_h, index = .02, 18
            data = prepare(method, check_h, DURATION, gamma)
            point = Z0+.001*np.arange(4)
            new, ideal, _ = step_function(point, index, data, True)
            finite_differences = []
            for eps in [1e-4, 1e-5, 1e-6]:
                numeric = np.column_stack([(step_function(point+eps*I4[j], index, data, False)[0]-step_function(point-eps*I4[j], index, data, False)[0])/(2*eps) for j in range(4)])
                discrepancy = float(np.linalg.norm(numeric-ideal, 2))
                assert discrepancy < 2e-8
                finite_differences.append({"difference_step": eps, "finite_difference_vs_ideal_tangent_error_spectral2": discrepancy,
                    "finite_difference_K_defect_spectral2": np.linalg.norm(numeric.T@structure((index+1)*check_h, new)@numeric-structure(index*check_h, point), 2)})
            derivative_checks.append({"method": method, "time_tau": index*check_h, "h": check_h, "state": point,
                "epsilon_sweep": finite_differences,
                "scope": "One representative step/state, three centered-difference scales; rounding and differencing errors remain. This is not an exact derivative certificate or a full-domain replacement for the ideal-map identity."})
        cases.append({"name": name, "kappa": kappa, "remaining_gamma": gamma, "initial_state": Z0,
                      "duration_tau": DURATION, "duration_seconds": DURATION/R["omega0_rad_s"], "steps_tau": STEPS,
                      "field": "X'=N Y; Y'=-N X-kappa*d*(sin(d^T X)-d^T X)-gamma Y",
                      "reference": ref_protocol, "maximum_reference_refinement_difference": refinement,
                      "methods": groups, "same_chart_specialization_check": equivalence, "representative_step_derivative_checks": derivative_checks})
    result = {"scope": "New-baseline two-mode method verification; physical coefficients unchanged. Known closed-field coefficients are mathematical diagnostic inputs, not information supplied to a learned controller.",
              "parameters": R, "units": "balanced phase coordinates and tau are dimensionless; SI readouts retain the supplied baseline",
              "common_model_setup_seconds": None, "common_model_setup_note": "Not separately timed: shared explicit four-dimensional formula construction. There is no symbolic compilation or numerical chart PDE solve; no measured-zero setup cost is asserted.",
              "cases": cases, "error_definitions": {"endpoint_error": "||z_N-z_ref(T)||_2", "maximum_grid_error": "max_k ||z_k-z_ref(t_k)||_2", "orders": "log(E_h/E_h2)/log(h/h2); endpoint and grid orders are distinct", "K_defect": "max_k ||Dpsi^T K(t_{k+1}) Dpsi-K(t_k)||_2; K(t)=exp(gamma*t)*(-J)", "exponential_conformal_defect": "max_k ||Dpsi^T J Dpsi-exp(-gamma*h)J||_2"},
              "Newton": {"tolerance_increment_inf": 2e-14, "maximum_corrections": 12, "failure_raises": True},
              "same_object_policy": "All methods within a case share field, initial state, horizon and reference. Central4 is absent from damped cases.",
              "control_policy": "Existing material-A four-group restoration/tracking trials are unchanged; no saturation, hardware calibration or new physical experiment is asserted.",
              "status": "all assertions passed"}
    write_result("magnetic_method_comparison.json", result)
    print("G1/G2: new-baseline chart specialization, endpoint/grid order, residuals, structure and measured costs passed", flush=True)
    return result
