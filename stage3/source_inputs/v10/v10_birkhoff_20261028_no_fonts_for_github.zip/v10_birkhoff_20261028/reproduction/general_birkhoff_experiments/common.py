"""Diagnostics and cost accounting for the local Birkhoff comparison.

No experiment runs at import. All quantities in the synthetic tests are
dimensionless. Timing excludes the independent reference and diagnostic
tangent/structure evaluation; required method preparation is included in
the cold timing and separately disclosed for the warm-cache timing.
"""
from pathlib import Path
import hashlib
import json
import platform
import time
import numpy as np
import scipy
from scipy.integrate import solve_ivp

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
BASELINE_PATH = HERE.parent / "new_baseline.json"
BASELINE_SHA256 = "2bac37b2f4444efc6a0ba742139fbf0b35e268e9f4f3597ba13a0793bc2049ac"
J = np.block([[np.zeros((2, 2)), np.eye(2)], [-np.eye(2), np.zeros((2, 2))]])
K0 = -J
I4 = np.eye(4)


def baseline():
    raw = BASELINE_PATH.read_bytes()
    if hashlib.sha256(raw).hexdigest() != BASELINE_SHA256:
        raise ValueError("The supplied material-A physical baseline changed; review the parameter version before running.")
    return json.loads(raw)


def clean(x):
    if isinstance(x, dict):
        return {str(k): clean(v) for k, v in x.items()}
    if isinstance(x, (tuple, list)):
        return [clean(v) for v in x]
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, np.generic):
        return x.item()
    return x


def write_result(name, result):
    import sympy
    result["provenance"] = {
        "baseline_file": "../new_baseline.json",
        "baseline_sha256": hashlib.sha256(BASELINE_PATH.read_bytes()).hexdigest(),
        "source_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(HERE.glob("*.py"))},
        "environment": {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__, "sympy": sympy.__version__, "platform": platform.platform(), "processor": platform.processor()},
        "parameter_policy": "Material A is the sole physical baseline. B's display-precision old-v10 values are not loaded.",
        "structure_policy": "Ideal implicit/conjugated tangents evaluated at floating-point states; no assertion that finite Newton code is exactly structure preserving.",
    }
    (HERE / name).write_text(json.dumps(clean(result), ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def newton(residual, derivative, predictor, tolerance=2e-14, max_corrections=12):
    z = predictor.copy()
    for corrections in range(max_corrections + 1):
        r = residual(z)
        rn = float(np.linalg.norm(r, np.inf))
        if rn <= tolerance:
            return z, rn, corrections
        if corrections == max_corrections:
            raise RuntimeError("Increment Newton solve failed its residual test")
        z -= np.linalg.solve(derivative(z), r)
    raise AssertionError("unreachable")


def midpoint_step(old, h, field, jacobian, diagnostics=True):
    residual = lambda z: z-old-h*field((z+old)/2)
    derivative = lambda z: I4-h*jacobian((z+old)/2)/2
    new, rn, corrections = newton(residual, derivative, old+h*field(old))
    stats = {"increment_residual_inf": rn, "Newton_corrections": corrections}
    tangent = None
    if diagnostics:
        d = h*jacobian((new+old)/2)/2
        tangent = np.linalg.solve(I4-d, I4+d)
        stats["minimum_Newton_matrix_singular_value"] = float(np.linalg.svd(I4-d, compute_uv=False)[-1])
    return new, tangent, stats


def integrate(prepared, step_function, initial, h, duration, diagnostics, structure=None, old_structure=None):
    n = int(round(duration/h))
    if abs(n*h-duration) > 1e-12:
        raise ValueError("duration must be an integer multiple of step")
    states = np.empty((n+1, len(initial)))
    states[0] = initial
    maxima = {}
    minima = {}
    sums = {}
    for k in range(n):
        new, tangent, stats = step_function(states[k], k, prepared, diagnostics)
        if not np.isfinite(new).all():
            raise FloatingPointError("non-finite trajectory")
        if diagnostics:
            for key, val in stats.items():
                if val is None:
                    continue
                if key.startswith("minimum_"):
                    minima[key] = min(minima.get(key, np.inf), float(val))
                else:
                    maxima[key] = max(maxima.get(key, 0.), float(val))
                if key.endswith("corrections"):
                    sums[key] = sums.get(key, 0) + int(val)
            if structure is not None:
                km = structure(k*h, states[k])
                kp = structure((k+1)*h, new)
                defect = np.linalg.norm(tangent.T@kp@tangent-km, 2)
                maxima["ideal_K_defect_spectral2"] = max(maxima.get("ideal_K_defect_spectral2", 0.), float(defect))
            if old_structure is not None:
                km = old_structure(k*h, states[k])
                kp = old_structure((k+1)*h, new)
                defect = np.linalg.norm(tangent.T@kp@tangent-km, 2)
                maxima["ideal_defect_against_uncontrolled_K_spectral2"] = max(maxima.get("ideal_defect_against_uncontrolled_K_spectral2", 0.), float(defect))
        states[k+1] = new
    stats = {"max_"+k: v for k, v in maxima.items()}
    stats.update(minima)
    stats.update({"total_"+k: v for k, v in sums.items()})
    stats["failed_steps"] = 0
    return states, stats


def time_method(prepare, step_function, initial, h, duration, repetitions):
    # Warm the numerical-library dispatch first. This unmeasured pass uses no
    # cache from the measured runs; each cold repetition rebuilds its own data.
    warmup = prepare()
    integrate(warmup, step_function, initial, h, duration, False)
    cold, setup_times, cold_advance, warm = [], [], [], []
    for _ in range(repetitions):
        t0 = time.perf_counter()
        prepared = prepare()
        t1 = time.perf_counter()
        integrate(prepared, step_function, initial, h, duration, False)
        t2 = time.perf_counter()
        cold.append(t2-t0)
        setup_times.append(t1-t0)
        cold_advance.append(t2-t1)
        t3 = time.perf_counter()
        integrate(prepared, step_function, initial, h, duration, False)
        warm.append(time.perf_counter()-t3)
    return {
        "repetitions": repetitions,
        "cold_total_seconds": cold,
        "required_setup_seconds": setup_times,
        "cold_advance_seconds": cold_advance,
        "warm_cached_advance_seconds": warm,
        "median_cold_total_seconds": float(np.median(cold)),
        "median_required_setup_seconds": float(np.median(setup_times)),
        "median_cold_advance_seconds": float(np.median(cold_advance)),
        "median_warm_cached_advance_seconds": float(np.median(warm)),
        "timing_scope": "Same process, single BLAS thread, one unmeasured dispatch warmup; cold includes every required per-grid method preparation. Independent references and ideal-tangent diagnostics excluded from every method. Common model-symbolic compilation reported separately.",
        "interpretation": "Implementation-specific wall time, not a universal efficiency or complexity claim.",
    }


def reference_pair(field, initial, duration):
    settings = [dict(rtol=1e-11, atol=1e-13, max_step=.05), dict(rtol=2e-13, atol=2e-15, max_step=.025)]
    solutions = [solve_ivp(lambda t, z: field(z), (0., duration), initial, method="DOP853", dense_output=True, **s) for s in settings]
    if not all(s.success for s in solutions):
        raise RuntimeError("DOP853 reference did not finish")
    return solutions, {"method": "Independent DOP853 in original coordinates", "settings": settings, "interval_enclosure": False}


def errors(states, ref, h, previous=None):
    e = np.linalg.norm(states-ref, axis=1)
    row = {"step": h, "endpoint_error": float(e[-1]), "maximum_grid_error": float(np.max(e)), "RMS_grid_error": float(np.sqrt(np.mean(e*e)))}
    for key in ["endpoint_error", "maximum_grid_error"]:
        row[key+"_order"] = None if previous is None else float(np.log(previous[key]/row[key])/np.log(previous["step"]/h))
    return row
