# Local Birkhoff method comparisons added to material A

This directory adds method verification to the supplied v10 manuscript. It
does not replace its physical baseline, its fitted coefficients, its controller,
or its existing experiment records. `new_baseline.json` must retain the supplied
SHA256 `2bac37b2f4444efc6a0ba742139fbf0b35e268e9f4f3597ba13a0793bc2049ac`.

## Reproduce

Use Python 3 with NumPy, SciPy and SymPy. From the project root:

```sh
python reproduction/general_birkhoff_experiments/run_all.py
python reproduction/general_birkhoff_experiments/build_assets.py --language en
```

The first command runs both comparison families, requires at least three
timing repetitions, and verifies that every protected material-A numerical
record is unchanged. `--experiment magnetic` or `--experiment synthetic`
selects one family. The second command reads the resulting JSON and updates
only the two new English numerical sections. It runs no numerical experiment.
The Chinese version was completed after freezing the reviewed English master.
To regenerate only the two added Chinese fragments, use
`python reproduction/general_birkhoff_experiments/build_assets.py --language zh`.
To regenerate all four Chinese numerical inputs owned by this integration,
including the minimally revised material-A chapters, use
`python reproduction/general_birkhoff_experiments/build_chinese.py`.
This Chinese-only entry verifies the pinned English versions, preserves the
local templates under `framework_experiments/authoring`, reads the same result
JSON for the new tables, and checks exact bilingual mathematics, references,
numerical values, environment order and paragraph-level mathematics. It writes
no English source, figure or numerical experiment result. The separate tracking
extension is owned by the route translation workflow.

The read-only checker is
`python reproduction/general_birkhoff_experiments/check_translation.py`.
It writes its QA report to `reviews/fusion_numerics_translation_checks.json`.

## Objects and comparable methods

| Group | Single object within each comparison | Methods |
| --- | --- | --- |
| G1 | New physical baseline with full cosine and known `(kappa,gamma)=(1.2,.05)` or `(1.02,.01)`; initial state `(.09,.08,.015,-.01)`, dimensionless time `[0,4]`, steps `.04,.02,.01,.005` | Ordinary midpoint; direct weighted midpoint; independently implemented canonical chart midpoint with `chi_t=(X,exp(gamma*t)Y)` |
| G2 | The same baseline's autonomous conservative `h0`, `(kappa,gamma)=(1,0)`, same initial state/time/steps as G1 | The three coincident midpoint specializations; Central4 with all full-cosine derivatives |
| G3 | Material B's artificial variable-mass, nonproportional-drag model; separate uncontrolled and controlled fields; initial state `(.25,-.18,.03,.04)`, dimensionless time `[0,2]`, steps `.2,.1,.05,.025` | Ordinary midpoint; Birkhoff chart midpoint; no proportional weighted/Central4 claim |

G1's known field coefficients are method-test inputs, not unknown truth made
available to a learning controller. Existing material-A restoration and
tracking comparisons keep their original four controller groups and ideal
magnetic port assumptions. G3's control is an unrestricted, fully actuated
two-coordinate synthetic force, without learning or magnetic realization.
It is not another physical catheter experiment.

## Error and residual conventions

Both endpoint Euclidean error and full-grid maximum Euclidean error are
stored, with separate halving orders. Magnetic references are independent
DOP853 solves with two tolerance settings. G3 references use the known
linear conjugacy and are checked by independent original-coordinate DOP853.
Refinement differences are floating-point checks, not interval enclosures.

The structure metric is the maximum spectral 2-norm of
`Dpsi.T @ K(z_next,t_next) @ Dpsi - K(z,t)`. `Dpsi` is the ideal
implicit/conjugated tangent evaluated at solved points. A finite floating-point
Newton program is not asserted to be exactly structure preserving. G3 also
checks a finite-difference derivative of the composed map and the endpoint
compatibility identity. Its controlled map is checked against both the
correct closed-loop `K_u` and the original uncontrolled `K`.

Ordinary/weighted/nonlinear magnetic-chart Newton equations use full increment
infinity tolerance `2e-14`, at most 12 corrections, and raise on failure.
G3 chart midpoint is a **linear** solve: its nonlinear-increment Newton fields
are `null`, not zero. Its linear chart increment and inverse-coordinate
residual are reported separately. The scalar inverse point map uses a
function-residual tolerance `5e-15`, at most 30 corrections. A small residual
of one equation is not interchangeable with a residual in different
coordinates without the corresponding derivative/conditioning bounds.

## Cost accounting

The driver sets OpenBLAS, OpenMP and MKL threads to one before numerical
imports. Each method/grid receives one unmeasured dispatch warmup and at
least three cold/warm measured repetitions in the same process. The JSON
stores every time and its median. No timing includes independent reference
generation or ideal-tangent diagnostic evaluation.

Cold time includes all required grid-specific preparation and state advances.
For G3 this includes `(2*N+1)` matrix exponentials and principal square roots,
`N` Sylvester solves, all dense linear solves and the entire update cache.
The warm advance time deliberately reuses that cache. The known conjugacy
makes such a cache possible; it is not available for an arbitrary unknown
time/state-dependent Birkhoff construction. One-off symbolic construction
of the original mechanical field and Jacobian is reported separately.
Timings describe this implementation and do not establish a general speed
advantage, especially between synthetic and physical objects.

## Result files

- `magnetic_method_comparison.json`: G1/G2 full series, independent references,
  same-chart equivalence, residuals, structure metrics, timings and source hashes.
- `synthetic_method_comparison.json`: G3 full series, exact/DOP853 comparison,
  endpoint/tangent checks, old/new controlled structures and costs.
- `run_validation.json`: protected material-A record hashes before/after.
- `numerical_provenance.json`: exact JSON inputs and displayed values used by
  the two added English sections.
- `numerical_provenance_zh.json`: the same numerical inputs and values used by
  the two complete Chinese translations.
- `preserved_chinese_templates.json`: frozen-English hashes and local Chinese
  template paths for the existing numerical chapters.

Material B's `verify_v10_special_case.py` and `v10_results.json` use old v10
display-precision coefficients. They remain historical input material and
are not imported by this directory. No new COMSOL, full CHNN, 64-mode closed
loop, hardware or finite-amplitude KAM certificate is produced here.
