"""Run the material-A/B method comparisons without modifying old results.

python reproduction/general_birkhoff_experiments/run_all.py
Optional: --experiment magnetic|synthetic and --timing-repetitions 3.
"""
import os
os.environ.update(OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", PYTHONDONTWRITEBYTECODE="1")
import argparse
import hashlib
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--experiment", choices=["all", "magnetic", "synthetic"], default="all")
    parser.add_argument("--timing-repetitions", type=int, default=3)
    args = parser.parse_args()
    if args.timing_repetitions < 3:
        parser.error("Use at least three measured repetitions for the reported median")
    here = Path(__file__).resolve().parent
    protected = [here.parent/"new_baseline.json"]
    for name in ["experiments", "framework_experiments"]:
        protected += list((here.parent/name).glob("*.json"))
    hashes = {str(p.relative_to(here.parent)): hashlib.sha256(p.read_bytes()).hexdigest() for p in protected}
    if args.experiment in ["all", "magnetic"]:
        from magnetic import run
        run(args.timing_repetitions)
    if args.experiment in ["all", "synthetic"]:
        from synthetic import run
        run(args.timing_repetitions)
    after = {str(p.relative_to(here.parent)): hashlib.sha256(p.read_bytes()).hexdigest() for p in protected}
    assert hashes == after, "An existing baseline or experiment record was modified"
    report = {"status": "all selected experiments passed", "selected_experiment": args.experiment,
              "timing_repetitions": args.timing_repetitions, "existing_baseline_and_results_unchanged": True,
              "protected_source_sha256": hashes,
              "new_results": [p.name for p in sorted(here.glob("*_method_comparison.json"))]}
    (here/"run_validation.json").write_text(json.dumps(report, ensure_ascii=False, indent=2)+"\n")
    print(json.dumps(report, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
