V10 + GENERAL BIRKHOFF: MINIMAL FUSION OF MATERIALS A AND B
28 October 2026
========================================================

1. Manuscript identity and two complete research routes

Material A (v10_英文中文整合源码与复算包.zip) is the sole manuscript,
physical-parameter and pre-existing numerical baseline. Its six-section
organization, sagej.cls, valid formulas, proofs, bibliography and proportional-
damping realization are retained. Material B supplies a local general Birkhoff
extension and a separately identified artificial verification model.

Direction I: mechanics -> Hamiltonian/CHNN residual model -> local Birkhoff
structure -> compatible endpoint generator -> difference method -> residual
compensation -> actual closed-loop structure and convergence -> conditional
discrete KAM.

Direction II: CHNN and identification error -> normal form and twist -> KAM
for the learned conservative reference -> magnetic tracking and clearance.
Both directions have their defining equations, results and conclusions in
the main article. Detailed proofs and protocols remain in the supplement.
Their common residual delta R gives h_c=h_0+delta R and h_hat=h_*-delta R.
The normal forms, analytic domains and perturbation budgets are distinct.

english/main.tex and english/supplement.tex are the reviewed English master.
chinese/ contains the corresponding complete translation. The four PDFs are
in output/. Formula numbers are assigned by the final integrated documents;
"original (36)" denotes the historical source's ordinary midpoint, not the
new document's equation numbered 36. See the original-to-fusion label map.

2. Exact source provenance and current comparison records

Material A archive SHA256:
121fec60cea516667b964bfe4c593492c711c70542c92bddf33d9f7a62c53b81
Material B archive SHA256:
c7df06ff2aaaf877f11133c18fca35d07c998b85648375e16bb3b2acbe78809a
Frozen physical baseline, reproduction/new_baseline.json, SHA256:
2bac37b2f4444efc6a0ba742139fbf0b35e268e9f4f3597ba13a0793bc2049ac

provenance/material_A_sources/ preserves all original A LaTeX sources.
provenance/material_B_original/ preserves the eight original B files.
reviews/fusion_audit/fusion_audit_stage1.json is the pre-edit read-only audit
(65 fusion decisions). The final workbook adds actual locations and statuses.
provenance/material_A_to_fusion.diff and material_A_comparison.json are the
current comparison against A. provenance/fusion_notation_map.json records
meaning, dimensions and units for potentially conflicting notation.

Older upstream-v10 and Direction-I maps/diffs in provenance/ and reviews/
are retained historical records from A. They do not describe this revision's
current two-route scope. In particular, integration_patch.diff is historical;
material_A_to_fusion.diff is the current review patch. The source archive is
complete and does not require application of either patch to compile.
The upstream repository/commit records are inherited provenance; this fusion
uses the supplied A archive and does not silently switch to a repository head.

3. Build the four manuscripts

Requirements: Python 3 and TeX with pdfLaTeX, XeLaTeX, xdvipdfmx, amsmath,
amssymb, amsthm, mathtools, graphicx, booktabs, array, tabularx, multirow,
microtype, etoolbox, xr-hyper, hyperref, fontspec and Latin Modern OpenType
fonts. sagej.cls is supplied. Compatible xeCJK/ctex packages are in texmf/;
CJK fonts and licenses are in fonts/.

    python3 build_pdfs.py --language en
    python3 build_pdfs.py --language zh

Builds use isolated directories and ordered cross-reference passes. No
unresolved reference, missing character or overfull box is accepted in the
final log. Chinese documents use XDV passes followed by xdvipdfmx.
Keep each main PDF beside its supplement for the relative PDF cross-links.
Do not regenerate figures concurrently with a document build.

4. Numerical reproduction

Install the tested numerical dependencies from requirements.txt. SymPy is
needed for the added variable-mass model and exact polynomial verification.
From this directory:

    python3 reproduction/run_all.py

This verifies A's FE calculation against its frozen file, then reruns the
original control/tracking/damping tests, the original matrix/convergence
suite, the added method comparisons and the separate normal-form budgets.
The FE verifier runs the unchanged original script in a temporary directory;
it never overwrites the official physical baseline. Environment-dependent
roundoff diagnostics are compared with stated absolute tolerances. Running
reproduce_baseline.py directly writes a candidate in its own directory; use
the verifier for the delivered frozen benchmark.

Individual new entry points:

    python3 reproduction/verify_baseline.py
    python3 reproduction/general_birkhoff_experiments/run_all.py
    python3 reproduction/route_budget/run_all.py
    python3 reviews/check_general_identities.py
    python3 reviews/check_route_budgets.py

The current revision actually reran the FE verifier, 56 method/grid cases,
the two normal-form budgets and the symbolic checks. Unaffected A controller,
tracking, damping and algebraic-defect records are retained and identified
as prior reproduced results; they were not relabeled as new experiments.
The all-suite command is supplied for a fresh full reproduction.

The new method comparison records every initial state, time interval, step,
parameter identity, reference method, error definition, residual, ideal-map
structure diagnostic and three-repeat cost measurement. Timing varies by
machine. Full cold setup cost and cached advance time are distinguished.
The original control groups retain the same initial state, target, ideal
actuation assumptions and input settings within each comparison.

Generated English numerical fragments can be refreshed separately:

    python3 reproduction/framework_experiments/build_manuscript_assets.py
    python3 reproduction/general_birkhoff_experiments/build_assets.py
    python3 reproduction/route_budget/run_all.py --render-existing --language en

Chinese numerical fragments are regenerated with:

    python3 reproduction/general_birkhoff_experiments/build_chinese.py
    python3 reproduction/route_budget/run_all.py --render-existing --language zh

The first command synchronizes the two revised base numerical inputs and the
two added inputs, preserving frozen mathematics. The older index-based
translate_framework_numerics.py is historical and should not overwrite these
fusion sections. The unchanged tracking result translation is already included.

The figures and numerical fragments do not run experiments themselves.
A numeric rerun changes source hashes and invalidates the delivered English
freeze. Review the new values, synchronize the Chinese fragments, then rebuild
and validate both languages; do not present the old frozen validation as a
certificate for modified outputs. New experiment directories contain their
own detailed reproduction instructions.

5. Mathematical scope and evidence status

The transported-one-form result proves local existence on a smooth regular
ODE domain. The exact inverse flow gives an existence construction; it is not
an efficient general catheter solver. Moser-compatible charts and endpoint
projection require their stated local invertibility and domain conditions.
The explicit proportional-damping case remains the practical instance.

Ordinary physical-coordinate midpoint, weighted midpoint and general chart
midpoint are distinguished. Weighted and chart maps are algebraically equal
only for the specified proportional chart. Fourth-order Central4 is compared
on the same autonomous conservative energy. The variable-mass, nonproportional
example uses declared dimensionless synthetic matrices and a known conjugacy;
it is not catheter material data, a device experiment or a universal algorithm.

Continuous generalized force, a discrete state increment, magnetic force and
torque, and field/gradient commands have different units. Two magnetic channels
cannot realize an arbitrary high-dimensional modal force. Existing port-rank,
residual and enriched-model limitations remain in the article.

The ideal exactly solved map satisfies the stated structure identity. Floating-
point solves and finite-difference tangent checks have explicitly reported
residuals and do not establish exact arithmetic preservation. Discretization
error, tracking error, energy change and structure defects are separate outputs.
A fixed learning error remains when the step tends to zero.

Each KAM claim names its conservative Hamiltonian or autonomous symplectic
map, normal form, twist, complex domain, divisors and error budget. A general
time-dependent Birkhoff identity alone does not establish standard autonomous
map KAM. The new small-domain remainder bounds are floating-point evaluations
of proved majorants, not outward-rounded physical uncertainty intervals.
The theorem constants and full Diophantine/smallness certificate are unfinished.
The auxiliary KAM domain does not cover the control-test initial amplitudes.

6. Physical-source policy and work that remains

Published material values are tied to stated preparation conditions. Magnet
values use cited manufacturer-grade specifications and declared geometry.
The derived endpoint mass, rotary inertia, dipole, modal scales and frequencies
are reproduced. Geometry choices, nominal damping, test gains, initial states
and grids are declared design/validation choices, not measured literature data.
A reasonable source can be a documented design choice or a derivation; it is
never an invented attribution to a paper.

Unfinished: specimen and damping identification; coil/gradient calibration;
noise, saturation and contact tests; full new-baseline CHNN training; retained-
controller 2/4/8/64-mode nonlinear closed-loop validation; independent COMSOL;
a demonstrated energy governor that enforces the clearance budget; and a
validated finite-amplitude KAM certificate. The linear 64-DOF FE mesh check
is not a completed 64-mode controlled experiment. Old v10 values remain
historical examples and are not substituted for new-baseline results.

7. Final integrity records

provenance/fusion_stages.json records the required audit -> English -> checks
-> Chinese sequence. english_master_freeze.json hashes the reviewed English.
The final validation compares equations, inline mathematics, labels, citations
and numbering across languages. Formula-preservation and label-migration
records distinguish retained formulas from necessary additions. The separate
revision/reproduction report gives findings and remaining work in Chinese.
MANIFEST.json lists delivered files and hashes. Compiler scratch files and
review images are excluded from the archive; no third-party full reference
books or papers used during the audit are redistributed.
