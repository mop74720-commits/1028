"""Check the four theory translations against the frozen English master.

No LaTeX build is performed.  Optional --baseline compares retained Chinese
displays, proof environments and labels with the immutable material-A tree.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re


ROOT = Path(__file__).resolve().parents[1]
FILES = (
    "structure.tex", "controlled_analysis.tex", "supp_structure.tex",
    "supp_general_birkhoff.tex",
)
DISPLAY = re.compile(
    r"\\begin\{(equation\*?|align\*?|gather\*?|multline\*?)\}(.*?)\\end\{\1\}",
    re.S,
)
UNNUMBERED = re.compile(r"\\\[(.*?)\\\]", re.S)
INLINE = re.compile(r"(?<!\\)\$((?:\\.|[^$])*?)(?<!\\)\$", re.S)
LABEL = re.compile(r"\\label\{([^}]+)\}")
REF = re.compile(r"\\(?:eqref|ref|pageref)\{([^}]+)\}")
CITE = re.compile(r"\\cite[a-zA-Z]*(?:\[[^\]]*\])*\{([^}]+)\}")
ENV = re.compile(r"\\(begin|end)\{([^}]+)\}")
INPUT = re.compile(r"\\input\{([^}]+)\}")
PROOF = re.compile(r"\\begin\{proof\}.*?\\end\{proof\}", re.S)


def strip_comments(text):
    return re.sub(r"(?<!\\)%[^\n]*", "", text)


def math_key(text):
    text = re.sub(r"\\text\{[^{}]*\}", r"\\text{}", text)
    return re.sub(r"\s+", "", text)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sequence_checks(left, right):
    sequences = {
        "numbered_display_math": (
            [math_key(s) for _, s in DISPLAY.findall(left)],
            [math_key(s) for _, s in DISPLAY.findall(right)],
        ),
        "unnumbered_display_math": (
            [math_key(s) for s in UNNUMBERED.findall(left)],
            [math_key(s) for s in UNNUMBERED.findall(right)],
        ),
        "inline_math": (
            [math_key(s) for s in INLINE.findall(left)],
            [math_key(s) for s in INLINE.findall(right)],
        ),
    }
    for name, pattern in (
        ("labels", LABEL), ("references", REF), ("citation_keys", CITE),
        ("environment_order", ENV), ("inputs", INPUT),
    ):
        sequences[name] = (pattern.findall(left), pattern.findall(right))
    result = {}
    for name, (a, b) in sequences.items():
        result[name] = {
            "english_count": len(a), "chinese_count": len(b), "equal_in_order": a == b,
        }
        assert a == b, (name, a, b)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline", type=Path)
    args = parser.parse_args()
    freeze_path = ROOT / "provenance/english_master_freeze.json"
    freeze = json.loads(freeze_path.read_text(encoding="utf-8"))
    changed = [rel for rel, sha in freeze["files"].items()
               if digest(ROOT / rel) != sha]
    assert not changed, ("English freeze changed", changed)
    report = {
        "stage": "4_chinese_theory_translation",
        "english_freeze": "provenance/english_master_freeze.json",
        "all_frozen_english_files_unchanged": True,
        "translation_policy": "Only English fusion edits translated; original material-A Chinese prose, displays and proofs retained wherever unchanged.",
        "terminology": {
            "chart": "图表", "chart midpoint": "图表中点",
            "residual damping": "残余阻尼", "ideal tangent": "理想切映射",
            "one-form transport": "一形式输运",
        },
        "files": [],
        "compile_performed": False,
        "visual_review": "Pending parent-controlled Chinese compilation and rendered-page review.",
    }
    for name in FILES:
        en = ROOT / "english/sections" / name
        zh = ROOT / "chinese/sections" / name
        left = strip_comments(en.read_text(encoding="utf-8"))
        right = strip_comments(zh.read_text(encoding="utf-8"))
        entry = {
            "file": name, "english_sha256": digest(en), "chinese_sha256": digest(zh),
            "checks": sequence_checks(left, right),
        }
        if name == "supp_general_birkhoff.tex":
            blocks_en = re.split(r"\n\s*\n", left.strip())
            blocks_zh = re.split(r"\n\s*\n", right.strip())
            assert len(blocks_en) == len(blocks_zh), "New supplement block omission"
            entry["full_new_file_block_counts"] = {
                "english": len(blocks_en), "chinese": len(blocks_zh),
            }
        elif args.baseline:
            original = (args.baseline / "chinese/sections" / name).read_text(encoding="utf-8")
            displays = [m.group(0) for m in DISPLAY.finditer(original)]
            displays += [m.group(0) for m in UNNUMBERED.finditer(original)]
            proofs = PROOF.findall(original)
            labels = LABEL.findall(original)
            assert all(block in right for block in displays), (name, "original display altered")
            assert all(block in right for block in proofs), (name, "original proof altered")
            assert all(label in LABEL.findall(right) for label in labels), (name, "original label removed")
            entry["original_chinese_preservation"] = {
                "display_blocks_retained_verbatim": len(displays),
                "proof_environments_retained_verbatim": len(proofs),
                "labels_retained": len(labels),
            }
        report["files"].append(entry)
    report["all_checks_passed"] = True
    destination = ROOT / "reviews/fusion_theory_translation_checks.json"
    destination.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("All four theory files match frozen English mathematics, labels, references, citation keys and environment order.")
    print("English master unchanged; no build executed.")
    for entry in report["files"]:
        print(entry["file"], {key: val["english_count"] for key, val in entry["checks"].items()})


if __name__ == "__main__":
    main()
