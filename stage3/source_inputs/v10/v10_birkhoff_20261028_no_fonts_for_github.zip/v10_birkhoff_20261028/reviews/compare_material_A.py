"""Produce a transparent label/formula/source diff against the sole Material A baseline."""
from pathlib import Path
import re,json,hashlib,difflib,collections
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'provenance/material_A_sources'
DISP=re.compile(r'\\begin\{(equation\*?|align\*?|gather\*?|multline\*?)\}(.*?)\\end\{\1\}',re.S)
LAB=re.compile(r'\\label\{([^}]+)\}')
def clean(s):return re.sub(r'(?<!\\)%[^\n]*','',s)
def math_key(s):return re.sub(r'\s+','',re.sub(r'\\text\{[^{}]*\}',r'\\text{}',s))
def aux(lang):
    result={}
    for name in ['main','supplement']:
        p=ROOT/lang/(name+'_xr.aux')
        for k,n,page in re.findall(r'\\newlabel\{([^}]+)\}\{\{([^}]+)\}\{([^}]+)\}',p.read_text()):result[k]={'number':n,'page':page,'document':name}
    return result
def main():
    summary=[];patch=[];oldlabels=[];newlabels=[];maths=[]
    for language in ['english','chinese']:
        for p in sorted((BASE/language).rglob('*.tex')):
            rel=p.relative_to(BASE);q=ROOT/rel
            a=p.read_text();b=q.read_text();oldlabels+=LAB.findall(clean(a));newlabels+=LAB.findall(clean(b))
            if a!=b:
                patch.extend(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='Material_A/'+str(rel),tofile='Fusion/'+str(rel)))
                summary.append({'path':str(rel),'old_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'new_sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'old_lines':len(a.splitlines()),'new_lines':len(b.splitlines())})
            oldblocks=[math_key(x) for _,x in DISP.findall(clean(a))]
            newblocks=[math_key(x) for _,x in DISP.findall(clean(b))]
            counts=collections.Counter(newblocks)
            kept=0;changed=[]
            for i,x in enumerate(oldblocks,1):
                if counts[x]:counts[x]-=1;kept+=1
                else:changed.append(i)
            maths.append({'path':str(rel),'original_display_blocks':len(oldblocks),'preserved_verbatim_math':kept,'not_found_in_same_file':changed})
    for language in ['english','chinese']:
        for p in sorted((ROOT/language).rglob('*.tex')):
            if not (BASE/p.relative_to(ROOT)).exists():
                newlabels+=LAB.findall(clean(p.read_text()))
                summary.append({'path':str(p.relative_to(ROOT)),'new_file':True,'new_lines':len(p.read_text().splitlines()),'new_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    inventory=json.loads((ROOT/'reviews/fusion_audit/source_inventory.json').read_text())
    source_labels=inventory['labels_A'];now=aux('english');mapping=[]
    for label,a in source_labels.items():mapping.append({'label':label,'material_A':a,'fusion':now.get(label),'retained':label in now})
    missing=sorted(set(oldlabels)-set(newlabels))
    result={'sole_baseline':'Material A archive, 121fec60cea516667b964bfe4c593492c711c70542c92bddf33d9f7a62c53b81','changed_files':summary,'mathematics':maths,'old_labels_missing':missing,'label_migration':mapping,'baseline_unchanged':hashlib.sha256((ROOT/'reproduction/new_baseline.json').read_bytes()).hexdigest()=='2bac37b2f4444efc6a0ba742139fbf0b35e268e9f4f3597ba13a0793bc2049ac'}
    (ROOT/'provenance/material_A_to_fusion.diff').write_text(''.join(patch))
    (ROOT/'provenance/material_A_comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps({'changed_files':len(summary),'original_display_blocks':sum(x['original_display_blocks'] for x in maths),'display_blocks_found_unchanged':sum(x['preserved_verbatim_math'] for x in maths),'old_labels_missing':missing,'baseline_unchanged':result['baseline_unchanged']},ensure_ascii=False))
    assert not missing
    assert result['baseline_unchanged']
if __name__=='__main__':main()
