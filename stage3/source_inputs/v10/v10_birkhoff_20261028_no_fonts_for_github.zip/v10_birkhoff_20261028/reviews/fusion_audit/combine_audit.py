from pathlib import Path
import json, hashlib, datetime

ROOT=Path(__file__).resolve().parent
inventory=json.loads((ROOT/'source_inventory.json').read_text())
labels=inventory['labels_A']
def txt(v):
    if isinstance(v,list): return '\n'.join(txt(x) for x in v)
    if isinstance(v,bool): return '是' if v else '否'
    return str(v or '')
def locations(ls):
    return '\n'.join(f"{x}：{labels[x]['document']} ({labels[x]['number']})，p.{labels[x]['page']}" if x in labels else x for x in ls)
rows=[]
for e in json.loads((ROOT/'root_audit.json').read_text())['entries']:
    rows.append(dict(id=e['id'],group='整体与物理接口',a_file=e['a_file'],a_labels=e['a_labels'],a_position=locations(e['a_labels']),a_role=e['a_role'],b=e['b_location']+'；'+e['b_construct'],equivalent=e['equivalent'],decision=e['decision'],reason=e['reason'],affected=e['downstream'],placement=e['placement'],rerun=e['rerun']))
for e in json.loads((ROOT/'general_theory_audit.json').read_text())['rows']:
    ls=[x['label'] for x in e['A_locations']]
    rows.append(dict(id=e['id'],group='一般Birkhoff与离散结构',a_file='english/sections/structure.tex; controlled_analysis.tex; supp_structure.tex',a_labels=ls,a_position=locations(ls),a_role=e['A_role'],b=e['B_correspondence'],equivalent=e['strict_equivalence'],decision=e['decision'],reason=e['mathematical_reason'],affected=txt(e['downstream_affected']),placement=e['placement'],rerun=txt(e['requires_new_experiment'])))
for e in json.loads((ROOT/'general_numerics_audit.json').read_text())['entries']:
    a=e['A_location'];ls=[a['label']] if a.get('label') else []
    rows.append(dict(id=e['id'],group='方法与实验',a_file=a['file'],a_labels=ls,a_position=locations(ls),a_role=e['A_role'],b=e['B_construction'],equivalent=txt(e['strictly_equivalent']),decision=e['disposition'],reason=e['mathematical_reason'],affected=txt(e['downstream_affected']),placement=e['placement'],rerun=e['rerun']))
rk=json.loads((ROOT/'routes_kam_audit.json').read_text())
for e in rk['entries']:
    rows.append(dict(id=e['id'],group='两路线与KAM',a_file=e['a_location'],a_labels=e['a_labels'],a_position=locations(e['a_labels']),a_role=e['a_role'],b=e['b_location']+'；'+e['b_construction'],equivalent=e['strict_equivalence'],decision=e['status'],reason=e['mathematical_reason'],affected=txt(e['downstream']),placement=e['placement'],rerun=e['rerun']))
refs=json.loads((ROOT/'general_theory_reference_checks.json').read_text())
refs += rk['reference_verification']
unique={}
for x in refs:
    k=x.get('key',x.get('citation_key',x.get('source','')))
    if not k:k=str(x)[:50]
    if k not in unique:unique[k]=x
    else:unique[k]['additional_check']=x
result={'stage':'阶段一只读审核完成，正文未改动','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'A_sha256':'121fec60cea516667b964bfe4c593492c711c70542c92bddf33d9f7a62c53b81','B_sha256':'c7df06ff2aaaf877f11133c18fca35d07c998b85648375e16bb3b2acbe78809a','rows':rows,'reference_checks':list(unique.values()),'source_inventory':'source_inventory.json'}
(ROOT/'fusion_audit_stage1.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print('Frozen audit rows:',len(rows))
