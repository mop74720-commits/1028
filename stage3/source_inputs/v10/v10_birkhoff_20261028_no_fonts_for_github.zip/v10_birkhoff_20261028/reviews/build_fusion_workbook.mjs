import fs from 'node:fs/promises';
import path from 'node:path';
import {Workbook, SpreadsheetFile} from '@oai/artifact-tool';
const root=process.env.V10_FUSION_ROOT || path.resolve(import.meta.dirname,'..');
const audit=JSON.parse(await fs.readFile(path.join(root,'reviews/fusion_audit_final.json'),'utf8'));
const outputDir=process.env.V10_DELIVERY_OUTPUT || path.join(root,'output');
await fs.mkdir(outputDir,{recursive:true});
const wb=Workbook.create();
const font='Noto Sans CJK SC';
const colors={navy:'#263F60',ink:'#202D3D',pale:'#F3F6FA',green:'#E7F1EB',amber:'#FFF1D6'};
function title(s,text,subtitle){
 s.showGridLines=false;s.tabColor=colors.navy;
 s.getRange('A2').values=[[text]];s.getRange('A2').format.font={name:font,size:16,bold:true,color:'#1C3554'};
 s.getRange('A3').values=[[subtitle]];s.getRange('A3').format.font={name:font,size:10,color:colors.ink};
 s.getRange('A2:A3').format.rowHeight=27;
}
function table(s,start,headers,rows,widths,name){
 const end=start+rows.length;const last=String.fromCharCode(64+headers.length);
 s.getRange(`A${start}:${last}${start}`).values=[headers];
 if(rows.length)s.getRange(`A${start+1}:${last}${end}`).values=rows;
 const all=s.getRange(`A${start}:${last}${end}`);all.format.font={name:font,size:10,color:colors.ink};all.format.verticalAlignment='top';all.format.wrapText=true;
 widths.forEach((w,i)=>s.getRangeByIndexes(start-1,i,rows.length+1,1).format.columnWidthPx=w);
 const head=s.getRange(`A${start}:${last}${start}`);head.format={fill:colors.navy,font:{name:font,size:10,bold:true,color:'#FFFFFF'},rowHeight:34,wrapText:true,verticalAlignment:'center',horizontalAlignment:'center'};
 rows.forEach((r,i)=>{
  const range=s.getRangeByIndexes(start+i,0,1,headers.length);if(i%2)range.format.fill=colors.pale;
  const lines=Math.max(...r.map((cell,j)=>String(cell??'').split('\n').reduce((sum,line)=>sum+Math.max(1,Math.ceil([...line].reduce((n,c)=>n+(c.charCodeAt(0)>255?1:.56),0)/(widths[j]/13-1))),0)));
  range.format.rowHeightPx=Math.max(name==='LabelMigration'?46:(name==='FusionOverview'?48:90),lines*18+18);
 });
 const t=s.tables.add(`A${start}:${last}${end}`,true,name);t.style='TableStyleLight9';
 s.freezePanes.freezeRows(start);
}
const summary=wb.worksheets.add('修订总览');
title(summary,'v10 × 一般 Birkhoff｜融合修订总览','以材料 A 为唯一底稿；英文先核验与冻结，再完整同步中文。');
const overview=[
 ['只读融合审核',`${audit.counts.audit_rows} 项；原始判断冻结保留，实施结果逐项映射`],
 ['原稿与融合稿标签',`${audit.counts.original_labels} 个原标签全部保留；最终 ${audit.counts.final_labels} 个，新增 ${audit.counts.new_labels} 个`],
 ['正文结构','保留六章；方向一与方向二均含正文数学对象、关键公式、结果与结论'],
 ['物理与数值基准','A 的 new_baseline.json 保持逐字不变；旧 v10 系数和 B 合成矩阵不混入'],
 ['新复算范围','FE 1880 数值项复核；12 类符号恒等式；5 个对象、共 14 个对象/方法组合、56 个步长结果；两套正规形预算'],
 ...audit.evidence_status,
 ['阅读：融合对照','65 行原位置、等价判断、修订理由、影响、实际编号及验证状态；支持筛选'],
 ['阅读：公式编号迁移','全部 359 个标签；A 的旧编号/页码及中英文最终编号/页码'],
 ['阅读：文献核验','9 组原始来源与具体定理适用范围，包含未完成的阈值条件'],
 ['阅读：记号与单位','15 组同名/近似记号的含义、维度、单位及采用约定'],
 ['历史原（36）','对应 A 的普通中点 (29)–(30)。A 自身 (36) 是 Central4；最终编号见稳定标签表。'],
 ['关键保留边界','一般 Birkhoff 是局部存在；已知图表合成验证不是任意导管高效算法。辅助 KAM 复域不覆盖控制初始幅值。'],
 ['复算总入口','python3 reproduction/run_all.py；各子入口、结果路径及限制见交付说明与 README.txt'],
 ['正式参数文件 SHA256',audit.baseline_sha256],
 ['材料 A SHA256',audit.A_sha256],
 ['材料 B SHA256',audit.B_sha256]
];
table(summary,5,['项目','当前交付状态'],overview,[240,1020],'FusionOverview');
const s=wb.worksheets.add('融合对照');
title(s,'原稿—融合稿逐项对照','原审核判断与实际实施结果并列；公式/节号沿用 LaTeX 标签追溯。');
const headers=['编号','主题','A 原位置与公式','原作用','B 对应构造','是否严格等价','原审核决定','最终实施位置','实际实施状态','数学理由','影响的后续内容','正文或补充','是否需要重算','验证依据与记录'];
const rows=audit.rows.map(r=>[r.id,r.group,r.a_file+'\n'+r.a_position,r.a_role,r.b,r.equivalent,r.decision,r.actual_location,r.implementation_status,r.reason,r.affected,r.placement,r.rerun,r.verification+'\n'+r.evidence_paths.join('\n')]);
table(s,5,headers,rows,[75,150,365,240,310,280,155,620,370,450,300,230,330,420],'FusionAudit');
s.freezePanes.freezeColumns(3);
const ls=wb.worksheets.add('公式编号迁移');
title(ls,'公式、定理与章节标签迁移','页码可因语言而不同；公式与定理编号在中英文间严格一致。');
const lr=audit.label_migration.map(r=>[
 r.status,r.label,r.source_file,r.A?.document==='main'?'正文':r.A?.document==='supplement'?'补充':'新增',r.A?.number??'',r.A?.page??'',
 r.english.document==='main'?'正文':'补充',r.english.number,r.english.page,r.chinese.page]);
table(ls,5,['状态','稳定标签','当前源文件','A 文档','A 原编号','A 原页','融合文档','最终编号','英文页','中文页'],lr,[90,360,420,105,100,95,110,105,95,95],'LabelMigration');ls.freezePanes.freezeColumns(2);
const rs=wb.worksheets.add('文献核验');
title(rs,'原始文献与适用条件','定理编号、核验来源及结论边界；引用存在不等于新参数认证已经完成。');
const rr=audit.reference_checks.map(r=>[r.key||r.citation_key||r.source||'',r.title||r.verified||'',r.checked||r.access||'',r.limitation||r.limitations||r.scope||r.note||'',r.url||r.source_url||'']);
table(rs,5,['引用','题名与定位','核验记录','适用限制','原始来源'],rr,[160,350,560,460,420],'ReferenceChecks');rs.freezePanes.freezeColumns(1);
const ns=wb.worksheets.add('记号与单位');
title(ns,'同名变量、维度与单位核对','先确认数学作用和坐标层次，再决定统一或分别定义。');
const nr=audit.notation.map(r=>[r.symbol,r.material_A,r.material_B,r.fusion,r.dimension,r.units,r.decision]);
table(ns,5,['记号','材料 A 含义','材料 B 含义','融合稿约定','维度','单位／尺度','处理理由'],nr,[210,360,320,430,260,400,400],'NotationMap');ns.freezePanes.freezeColumns(1);
wb.recalculate();
const check=await wb.inspect({kind:'table',range:'融合对照!A5:C8',tableMaxRows:4,tableMaxCols:3,maxChars:1800});console.log(check.ndjson);
const errors=await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#NUM!',options:{useRegex:true,maxResults:20},maxChars:1000});console.log(errors.ndjson);
for(const [sheetName,range,file] of [
 ['修订总览','A1:B10','overview_preview.png'],['融合对照','A1:D9','audit_final_preview.png'],
 ['融合对照','G5:J9','implementation_preview.png'],['公式编号迁移','A1:J12','labels_preview.png'],
 ['文献核验','A1:C8','references_final_preview.png'],['记号与单位','A1:D9','notation_preview.png']]){
 const b=await wb.render({sheetName,range,scale:1,format:'png'});await fs.writeFile(path.join(outputDir,file),new Uint8Array(await b.arrayBuffer()));
}
const target=path.join(outputDir,'v10_Birkhoff_融合修改对照表.xlsx');await (await SpreadsheetFile.exportXlsx(wb)).save(target);
console.log(JSON.stringify({sheets:5,audit_rows:rows.length,labels:lr.length,reference_checks:rr.length,notation_rows:nr.length,output:target}));
