#!/usr/bin/env python3
"""Independent high-precision scale/rounding check, not interval certification."""
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import mpmath as mp

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "reproduction/route_budget/normal_form_budget_results.json"


def rational(value):
    f = Fraction(value)
    return mp.mpf(f.numerator)/f.denominator


def main():
    mp.mp.dps = 160
    data = json.loads(SOURCE.read_text())
    radius = mp.mpf("0.03")
    i_min, i_max = mp.mpf("0.0001"), mp.mpf("0.0002")
    rho_i, rho_phi = mp.mpf("0.000025"),mp.mpf("0.1")
    d = list(map(rational,data["parameters"]["d_exact"]))
    s = sum(abs(v) for v in d)*radius
    rin = mp.sqrt(2*(i_max+rho_i))*mp.cosh(rho_phi)
    bg_exact = mp.cosh(s)-1-s*s/2
    bg_finite = sum(s**(2*k)/mp.factorial(2*k) for k in range(2,15))
    bg_finite += s**30/mp.factorial(30)/(1-s*s/(31*32))
    assert bg_finite >= bg_exact
    tail_exact = mp.cosh(s)-1-s*s/2-s**4/24
    tail_bound = s**6*mp.cosh(s)/720
    assert tail_bound > tail_exact

    def majorant(terms):
        return sum(abs(rational(term["coefficient_exact"]))*radius**sum(term["powers"])
                   for term in terms)

    w = data["polynomials_at_kappa_one"]["W4"]
    m1 = max(sum(abs(rational(t["coefficient_exact"]))*t["powers"][j]
                 *radius**(sum(t["powers"])-1) for t in w if t["powers"][j])
             for j in range(4))
    b1 = majorant(data["polynomials_at_kappa_one"]["bracket_h4_W4"])
    b2half = majorant(data["polynomials_at_kappa_one"]["double_bracket_h2_W4_W4"])/2
    checks = []
    max_rel = mp.mpf(0)
    for row in data["routes"]:
        k = rational(str(row["kappa"]))
        m = k*m1
        ell = 3*m/radius
        rem = k*tail_bound+k*k*(b1+b2half)
        a = -k*d[0]**4/8
        b = -k*d[0]**2*d[1]**2/4
        c = -k*d[1]**4/8
        det = a*c-b*b
        center = (a+c)/2
        rad = mp.sqrt(((a-c)/2)**2+b*b)
        sigma = min(abs(center-rad),abs(center+rad))
        exacts = {"m_velocity_majorant":m,"ell_derivative_majorant":ell,
                  "image_margin":radius-rin-m,
                  "complete_normal_form_remainder_majorant":rem,
                  "twist_determinant":det,"twist_sigma_min":sigma}
        rels = {}
        for key,expected in exacts.items():
            relative = abs(mp.mpf(row[key])-expected)/abs(expected)
            max_rel = max(max_rel,relative)
            assert relative < mp.mpf("2e-14"),(key,relative)
            rels[key] = float(relative)
        assert exacts["image_margin"] > 0
        checks.append({"kappa":float(k),"relative_discrepancies":rels,
                       "image_margin_mp":mp.nstr(exacts["image_margin"],25),
                       "R6_majorant_mp":mp.nstr(rem,25)})
    bf_rel = abs(mp.mpf(data["shared_learning"]["B_g_majorant"])-bg_exact)/bg_exact
    assert bf_rel < mp.mpf("2e-14")
    report = {"status":"all independent high-precision checks passed",
              "source_sha256":hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
              "working_decimal_precision":mp.mp.dps,
              "maximum_relative_discrepancy":float(max_rel),
              "B_g_relative_discrepancy":float(bf_rel),
              "positive_series_tail_bound_is_upper":True,
              "cosine_degree_six_tail_bound_is_upper":True,
              "normal_form_inverse_flow_margin_positive_both_routes":True,
              "checks":checks,
              "scope":"Independent arithmetic check of analytic majorants; no outward-rounded interval or KAM theorem threshold certification."}
    target=ROOT/"reviews/route_budget_verification.json"
    target.write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report,indent=2))


if __name__=="__main__":
    main()
