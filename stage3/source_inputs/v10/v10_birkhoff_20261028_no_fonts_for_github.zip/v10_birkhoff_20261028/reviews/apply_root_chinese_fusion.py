"""Translate only root-owned fusion changes after the English freeze."""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
freeze=json.loads((ROOT/'provenance/english_master_freeze.json').read_text())
for rel,digest in freeze['files'].items():
    assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==digest

def replace(path,old,new):
    p=ROOT/path;s=p.read_text();assert old in s,(path,old[:60]);p.write_text(s.replace(old,new,1))

p=ROOT/'chinese/main.tex';s=p.read_text();a=s.index('\\begin{abstract}');b=s.index('\\end{abstract}',a)
s=s[:a]+r'''\begin{abstract}
磁性导管模型需要将力学降阶、学习补偿与数值动力学一致地连接起来。本文在同一个参数来源可追溯的平面梁上研究两条路线，保留耦合余弦磁势及端部惯量。第一条路线利用局部运输的一形式，为正则光滑的半离散向量场建立 Birkhoff 表示。相容的时变坐标图与端点生成函数导出保结构中点映射。比例阻尼保留显式的加权实现；普通中点则作为独立的实施与比较格式。利用状态的积分观测，在不使用加速度标签的条件下辨识势能残差与阻尼。所得补偿代入同一个隐式更新，并通过磁力和磁力矩实现。本文建立含有累积求解残差的有限时间收敛估计，并将其与相对于标称目标的误差区分开来。在自治保守分支上，由隐式方程精确定义的映射具有精确辛性，因而可开展条件性的离散 KAM 分析。第二条路线利用学习得到的哈密顿量生成保守参考，并由稳定的误差方程推导磁驱动跟踪。参考系统的 KAM 陈述与第一条路线闭环系统的陈述分别使用各自的正规形、定义域和扰动预算。矩阵检验、非线性磁模型与明确声明的变质量合成算例分别评价数值精度、几何缺陷与控制误差。一般局部存在结论与高效的高维算法保持区分。全模态实现、执行器标定和有限振幅 KAM 认证仍需满足相应的附加要求。
''' +s[b:]
s=s.replace('V10与方向一研究框架整合，2026年10月28日','V10与一般局部Birkhoff理论融合，2026年10月28日')
s=s.replace('\\section{补偿动力学的离散 KAM 持久性}','\\section{补偿动力学与学习参考的条件性 KAM}')
s=s.replace('\\input{sections/kam}','\\input{sections/kam}\n\\input{sections/route_interfaces}')
p.write_text(s)

p=ROOT/'chinese/supplement.tex';s=p.read_text();a=s.index('\\begin{abstract}');b=s.index('\\end{abstract}',a)
s=s[:a]+r'''\begin{abstract}
本补充材料给出正文所用的力学推导、局部 Birkhoff 与端点恒等式、受控映射分析、学习误差界和复算协议。残差补偿与学习参考跟踪共用同一组修订后的梁和端部磁体参数。比例阻尼公式作为一般局部构造的可计算实例予以保留。详细合成测试明确区分已知坐标图下的数学验证与一般导管算法。分别构造的正规形和解析域明确两项条件性 KAM 陈述各自作用的对象。最后一节包含完整的学习参考跟踪路线、误差界及数值证据；其关键公式和结论也保留在正文中。项目同时提供来源记录、修改前融合审核表及按公式标签组织的修改对照。
''' +s[b:]
s=s.replace('\\input{sections/supp_structure}','\\input{sections/supp_structure}\n\\input{sections/supp_route_budgets}')
s=s.replace('\\section{相关扩展：跟踪学习得到的保守参考}','\\section{学习参考的持久性与磁驱动跟踪}')
p.write_text(s)

p=ROOT/'chinese/sections/background.tex';s=p.read_text()
s=s.replace('控制器围绕该标称目标，补偿已辨识的保守残差和比例阻尼。因此，核心问题是：同一学习补偿能否与维度正确的差分格式、物理磁指令，以及对所得离散动力学的严格陈述相衔接。','一类控制器围绕该标称目标补偿已辨识的保守残差和比例阻尼，另一类控制器跟踪学习得到的保守模型所生成的参考轨迹。两条路线都需要维度正确的差分格式、物理磁指令，以及对各项保证所作用的动力学对象作出准确陈述。')
a=s.index('\\subsection{三个相互衔接的子问题}');b=s.index('\\subsection{贯穿全文的同一物理与统计模型}',a)
s=s[:a]+r'''\subsection{同一力学模型上的两条研究路线}
\label{fw:three-questions}
第一条路线将力学模型及其哈密顿残差表示依次连接到局部 Birkhoff 结构、相容生成函数、差分格式、残差补偿、受控收敛及条件性离散 KAM。一般局部构造扩展了显式的比例阻尼实现，同时保留这一可计算的导管实例。第二条路线将 CHNN 辨识及学习误差连接到学习保守参考的正规形与扭转，再连接到磁驱动跟踪和物理净空条件。两条路线共用参数、真实模型、残差定义和适用的辨识误差界，而参考轨迹及不变环面结论分别陈述。

在六节正文的推导过程中，需要回答三个实施问题。首先，力学质量矩阵、相流 Jacobian 和端点变换具有不同的维度；多模态矩阵实现必须区分这些对象。一般相容坐标图还明确了 Birkhoff 中点映射与物理坐标中普通中点的差别。其次，学习补偿必须使用已辨识模型、保留标称余弦耦合，并通过可用的力--力矩及磁场--梯度接口实现。较小的辨识损失本身既不验证激励充分性，也不验证硬件可行性。最后，所得格式必须收敛到实际受控向量场，其中包含固定的学习误差和代数求解残差。数值收敛、跟踪精度、能量平衡与二形式保持回答不同的问题。这些问题指导各项核验，而两条研究路线仍是全文分析的对象。

''' +s[b:]
s=s.replace('这些输入决定三个子问题共同使用的模态尺度、物理解码器和磁输入映射。','这些输入决定两条研究路线共同使用的模态尺度、物理解码器和磁输入映射。')
s=s.replace('本文采用比例阻尼下的构造性 Birkhoff 表示，推导其端点投影与时间中点更新，并在保守极限下恢复普通哈密顿中点映射。','首先，运输的一形式在光滑正则工作域上给出一般局部表示，相容坐标图使端点论证明确。本文保留比例阻尼的构造性表示、端点投影与时间中点更新，并在保守极限下恢复普通哈密顿中点。')
s=s.replace('连续 KAM 为保守目标提供背景 \\citep{poschel}，主要的离散结论则使用','连续 KAM 条件性地作用于各自的保守能量 \\citep{poschel}，补偿映射的离散结论则使用')
s=s.replace('学习一个保守参考并对其进行跟踪也是合理目标，但它产生不同的误差系统。该相关路线保留在补充材料~\\ref{sec:supp-tracking}；主文始终围绕残差补偿目标展开。','学习并跟踪保守参考所产生的误差系统，与补偿至标称动力学的误差系统不同。第~\\ref{kam:two-route-interface} 节和第~\\ref{app:learned-tracking-main} 节在正文中保留该路线的数学对象、控制器与数值结论。补充材料~\\ref{sec:supp-tracking} 给出其完整证明与协议。')
a=s.index('第一项贡献是从 Birkhoff');b=s.index('\\begin{table*}',a)
s=s[:a]+r'''本文在保持物理模型不变的前提下，将局部相容的 Birkhoff 一形式及端点投影连接到矩阵实现，进而将共同的积分辨识接入两类磁控制目标，并区分受控有限时间收敛与几何及 KAM 条件。已知的比例阻尼实例和明确声明的变质量、非比例阻尼合成算例展示了计算范围。后者验证一个已知的局部结构，并未建立任意耗散导管的低成本构造算法。

''' +s[b:]
a=s.index('\\caption{六节正文中的三个子问题。');b=s.index('\\end{table*}',a)
s=s[:a]+r'''\caption{保留的六节正文中的两条研究路线。全部物理量及学习量共用同一个明确声明的基准。}
\label{tab:roadmap}
\begin{tabularx}{\textwidth}{p{0.18\textwidth}YY}
\toprule
章节 & 共同构造 & 各路线的结论\\
\midrule
研究背景 & 物理对象、辨识范围及两类目标 & 分别陈述补偿与参考跟踪的结论\\
力学降阶 & 变分模型、局部 Birkhoff 形式、生成函数、矩阵格式和残差拟合 & 显式比例阻尼实例与学习保守参考\\
受控离散 & 将实际反馈代入隐式方程；精度与残差诊断 & 将收敛和结构分别与目标误差进行检验\\
条件性 KAM & 解析学习误差界及四次正规形 & $h_c$ 和 $\widehat h$ 各自的定义域及扰动预算\\
磁输入实现 & 共同力--力矩端口、扩充模型及净空条件 & 标称补偿与学习参考跟踪及各自的误差方程\\
结论 & 已建立的结果及计算范围 & 条件性持久性及待完成的全模型验证\\
\bottomrule
\end{tabularx}
''' +s[b:]
a=s.index('第~\\ref{sec:derivation} 节给出共同力学模型')
s=s[:a]+r'''第~\ref{sec:derivation} 节给出共同力学模型、一般与比例阻尼 Birkhoff 构造，以及离散和学习模型。第~\ref{sec:analysis} 节建立受控系统的有限时间性质，并报告方法和控制比较。第~\ref{sec:kam} 节明确两个保守 KAM 对象及各自的扰动预算。第~\ref{sec:application} 节通过相同的磁端口实现两类指令，并说明全梁与净空要求。第~\ref{sec:conclusion} 节汇总两条路线及尚待完成的验证。补充材料保留详细证明、数值协议和完整的参考跟踪分析。
'''
p.write_text(s)

replace('chinese/sections/mechanics.tex',r'其中 $M(q)=M(q)^{\mathsf T}\succ0$。弹性',r'其中 $q,p\in\mathbb R^n$，$M(q)=M(q)^{\mathsf T}\succ0$ 是 $n\times n$ 动能质量矩阵。工作域上必须采用独立的正则坐标；奇异约束系统须先完成约化，才能作为常微分方程处理。弹性')
replace('chinese/sections/mechanics.tex',r'补充材料~\ref{sm:exact-lift}；跟踪扩展在补充材料第~\ref{sec:supp-tracking} 节使用同一接口。',r'补充材料~\ref{sm:exact-lift}；学习参考跟踪路线在第~\ref{app:learned-tracking-main} 节及补充材料~\ref{sec:supp-tracking} 使用同一接口。')
p=ROOT/'chinese/sections/application.tex';s=p.read_text();b=s.index('\\subsection{')
s=r'''第一类应用目标是通过学习残差与阻尼补偿恢复耦合的标称磁动力学。第二类目标是通过相同的物理端口跟踪学习得到的保守参考。物理输入映射必须实现式~\eqref{struct:route-a-control} 的反馈，保留其中的估计误差，并采用与式~\eqref{ctrl:midpoint} 相同的中点约定。本文首先闭合两模态对象上的这一联系，再明确同一拟合控制器作用于更多梁模态时出现的附加项。全梁净空论证是关于物理能量的另一项条件。第~\ref{app:learned-tracking-main} 节给出第二条路线及其独立的误差系统；补充材料~\ref{sec:supp-tracking} 保留完整证明和数值协议。

''' +s[b:]
a=s.index('\\subsection{',s.index('\\label{app:ports}')+1)
s=s[:a]+'\\input{sections/tracking_main}\n\n'+s[a:]
p.write_text(s)

p=ROOT/'chinese/sections/conclusion.tex';s=p.read_text()
s=s.replace('三个子问题已通过同一个耦合磁模型连接起来。对于 P1，比例阻尼的 Birkhoff 表示、相容端点投影和生成函数导出维度一致的加权映射。','两条研究路线已通过同一个耦合磁模型连接起来。局部一形式运输构造给出一般 Birkhoff 表示，并明确其正则性、非退化性和坐标图条件。比例阻尼表示、相容端点投影和生成函数保留维度一致的加权映射。')
s=s.replace('对于 P2，积分观测','积分观测').replace('对于 P3，在隐式中点方程内加入反馈后','在隐式中点方程内加入反馈后')
s=s.replace('针对比例残余阻尼的加权格式保持相应的共形结构。','针对比例残余阻尼的加权格式保持相应的共形结构。一般相容控制可以保持原 Birkhoff 形式；否则，实际闭环向量场需要自身的形式。已知坐标图的合成计算验证了这一区别，并未建立高效的一般运输求解器。')
a=s.index('修订后的材料与磁体记录')
s=s[:a]+r'''学习参考路线保留为一套完整独立的构造。它使用 $\widehat h=h_* -\delta R$，补偿路线则使用 $h_c=h_0+\delta R$。两者的正则正规形与变换后的余项分别在各自定义域上评价；仅当两张图的像均位于误差界所控制的复邻域中时，才共用解析学习误差界。小域余项计算明确了预算中的一部分，而定理常数和完整非共振认证仍待完成。学习参考跟踪由含残差驱动的稳定误差方程及精确磁端口假设导出。其误差界不声称跟踪闭环具有辛性，也不能替代净空条件。

''' +s[a:]
s=s.replace('有限振幅 KAM 证书则要求在声明的定义域上验证解析余项和定理特定常数。因此，本文给出方向一的格式、控制器、受控收敛分析及可复现验证序列，同时明确保留这些后续认证要求。','有限振幅 KAM 证书要求在声明的定义域上验证余项、几何界、小除数界及定理特定常数。本文给出两条路线、共用的辨识和驱动接口，以及结构、收敛和控制的可复现检验序列。其余认证和全模型任务仍保留文中明确陈述的条件性状态。')
p.write_text(s)

p=ROOT/'chinese/sections/endmatter.tex';s=p.read_text()
a=s.index('在源码包根目录运行');b=s.index('\n\n原稿来源',a)
s=s[:a]+r'''在源码包根目录运行 \texttt{python3 reproduction/run\_all.py}，将先独立复核固定的力学基准，再执行残差控制检验、学习参考跟踪、阻尼扫描、研究框架验证组、一般 Birkhoff 比较和分别计算的正规形预算。基本计算需要 Python~3、NumPy 和 SciPy；一般合成模型与符号验证使用 SymPy，重绘论文图表使用 Matplotlib。构建说明另列 PDF 编译步骤。''' +s[b:]
s=s.replace('所提供的方向一研究框架决定本稿三个子问题的组织方式。源码包中的来源--章节对照表记录其格式、控制器、收敛论证和数值协议如何进入六节正文。','材料 A，即所提供的 v10 整合压缩包，是本次修订唯一的正文及物理数据基准。材料 B 提供经过审核的局部 Birkhoff 扩展与独立合成测试。六节组织方式和已经成立的公式予以保留。修改前融合审核记录两者的等价性、数学理由、后续依赖及所需复算；最终标签表定位保留和新增的各项结果。此前的研究框架--章节表作为历史来源记录保留。')
p.write_text(s)

# Bibliographic titles remain in their original language in both editions.
a=(ROOT/'provenance/material_A_sources/english/sections/references.tex').read_bytes()
b=(ROOT/'provenance/material_A_sources/chinese/sections/references.tex').read_bytes()
assert a==b
(ROOT/'chinese/sections/references.tex').write_bytes((ROOT/'english/sections/references.tex').read_bytes())
print('Root Chinese fusion passages synchronized after English freeze.')
