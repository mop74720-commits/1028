"""Join the frozen pre-edit audit with actual final source/aux locations."""
from pathlib import Path
import json,re,hashlib,collections
ROOT=Path(__file__).resolve().parents[1]

def load(p):return json.loads((ROOT/p).read_text())
def aux(language):
    out={}
    for doc in ['main','supplement']:
        for label,num,page in re.findall(r'\\newlabel\{([^}]+)\}\{\{([^}]+)\}\{([^}]+)\}',(ROOT/language/(doc+'_xr.aux')).read_text()):
            out[label]={'number':num,'page':page,'document':doc}
    return out

def main():
    original=load('reviews/fusion_audit/fusion_audit_stage1.json')
    inventory=load('reviews/fusion_audit/source_inventory.json')
    en,zh=aux('english'),aux('chinese')
    files={}
    for p in (ROOT/'english').rglob('*.tex'):
        for label in re.findall(r'\\label\{([^}]+)\}',p.read_text()):files[label]=str(p.relative_to(ROOT))
    implementations={}
    t=load('reviews/fusion_theory_edit_map.json')
    for row in t['rows']:
        implementations[row['audit_id']]={'labels':[x['label'] for x in row['fusion_targets']],
            'status':{'retained_and_linked':'原构造保留并补足衔接','local_revision_completed':'必要局部修订与补充证明已完成'}[row['implementation_status']],
            'evidence':'一般恒等式及中英理论核查已通过；数值验证见相应G1/G2/G3结果。',
            'paths':row.get('verification_results',[])}
    for row in load('reviews/fusion_routes_edit_map.json')['entries']:
        implementations[row['audit_id']]={'labels':row['new_or_retained_labels'],'status':row['status'],
            'evidence':row.get('verification_status',''),'paths':['reviews/fusion_routes_handoff.json','reproduction/route_budget/normal_form_budget_results.json']}
    numerics_status={
        'implemented and newly numerically verified':'已实施并完成受影响的新复算',
        'preserved or locally clarified; affected new comparisons completed; old numerical results not rerun':'原构造保留或局部澄清；受影响的新对照完成，未受影响A记录保留',
        'Existing complete route-B numerical evidence retained; restoration of main-text key route handled by route/KAM editor':'方向二完整数值证据保留，正文已恢复关键公式和结果',
        'Current authoring templates preserve added inputs and narrative headings; independent new generator renders two added sections; figure metadata noted for final asset synchronization':'中英生成模板与数值输入同步；四图数据、数学及版面已核查',
        'Explicitly remains incomplete/conditional; no new full-order or KAM certificate claimed':'明确保留尚待完成／条件性状态，未新增全阶或KAM证书'}
    for row in load('reviews/fusion_numerics_edit_map.json')['entries']:
        implementations[row['audit_id']]={'labels':row['final_labels'],'status':numerics_status.get(row['status'],row['status']),
            'evidence':'5个对象、14个对象/方法组合、56个步长结果；新旧记录和翻译按范围核对。',
            'paths':['reviews/general_numerics_validation.json','reviews/fusion_numerics_translation_checks.json']}
    overrides={
      'R01':['sec:background','tab:roadmap','kam:two-route-interface','app:learned-tracking-main','sec:conclusion'],
      'R02':['mech:general-energy','mech:general-hamiltonian','sm:variable-mass-momentum','struct:mechanical-midpoint'],
      'R03':['mech:parameters','mech:core-properties','mech:reduced-values','num:scales'],
      'R04':['struct:mechanical-midpoint','struct:matrix-elimination','struct:central4'],
      'R05':['mech:complex-chart','struct:birkhoff','struct:general-chart','struct:objects','mech:dimension-table'],
      'R06':['mech:modal-ports','app:port-inverse','app:field-gradient','app:input-reconstruction','app:learned-tracking-main'],
      'R07':['app:enriched-coordinates','app:enriched-closed-loop','app:conditional-lift'],
      'R08':['app:energy-bound','app:work-governor','sm:initial-upper-bound'],
      'R09':['sm:fluid-example','sm:contact-example','ss:general-transport'],
      'R10':['ctrl:global-error','ctrl:target-error-split','ctrl:power','ss:general-errors'],
      'R11':['sr:theorem-audit','ss:general-transport'],
      'R12':['sec:background','sec:conclusion','sec:supp-mechanics','sec:supp-tracking']}
    # Use the actual general-error subsection anchor (not an invented locator).
    if 'ss:general-errors' not in en:
        candidates=[k for k in en if k.startswith('ss:general-') and ('accuracy' in k or 'error' in k)]
        overrides['R10']=[k for k in overrides['R10'] if k!='ss:general-errors']+candidates
    root_status={
      'R01':'六章保留；两路线及摘要/导读/结论同步完成',
      'R02':'原力学公式保留；补独立正则坐标与矩阵维度',
      'R03':'A参数文件逐字保留；本轮独立FE复核1880数值项通过',
      'R04':'历史编号关系澄清；按稳定标签给出新旧编号',
      'R05':'首次定义与层次已核对；见记号与单位表',
      'R06':'原磁端口与两路控制方案保留；合成理想力单列',
      'R07':'原有高模态限制保留；完整64模态/COMSOL仍待完成',
      'R08':'物理能量净空条件保留；治理器仍待实现，未声称已验证',
      'R09':'光滑正则ODE范围明确；接触/DAE不作自动推广',
      'R10':'原收敛证明保留；补一般构造残差和图表误差项',
      'R11':'原参考体系保留，新增4条确实使用的来源；定理条件已核对',
      'R12':'四文档数学、行内式、标签、编号、引文和版面同步核查完成'}
    root_rows=[]
    for row in load('reviews/fusion_audit/root_audit.json')['entries']:
        ident=row['id'];implementation={'labels':overrides[ident],'status':root_status[ident],
            'evidence':{'R03':'reproduction/baseline_reverification.json；冻结baseline SHA不变',
                        'R12':'provenance/manuscript_validation.json；四篇编译均无未解引用、溢出或缺字',
                        'R11':'reviews/fusion_audit/fusion_audit_stage1.json；29条引用体系'}
                       .get(ident,'原稿保留比较、正文证明或所引用的实际数值/条件记录'),
            'paths':['provenance/material_A_comparison.json','provenance/fusion_notation_map.json']}
        implementations[ident]=implementation;root_rows.append({'audit_id':ident,**implementation})
    (ROOT/'reviews/fusion_root_edit_map.json').write_text(json.dumps({'stage':'completed','entries':root_rows},ensure_ascii=False,indent=2)+'\n')
    rows=[]
    for row in original['rows']:
        im=implementations[row['id']]
        for label in im['labels']:assert label in en and label in zh,(row['id'],label)
        locations=[]
        for label in im['labels']:
            ee,zz=en[label],zh[label]
            doc='正文' if ee['document']=='main' else '补充'
            locations.append(f"{label}：{doc} {ee['number']}；英文p.{ee['page']}／中文p.{zz['page']}")
        rows.append({**row,'actual_labels':im['labels'],'actual_location':'\n'.join(locations),
                     'implementation_status':im['status'],'verification':im['evidence'],'evidence_paths':im['paths']})
    migration=[]
    for label,pos in en.items():
        old=inventory['labels_A'].get(label)
        migration.append({'label':label,'source_file':files.get(label,''),'status':'保留' if old else '新增',
                          'A':old,'english':pos,'chinese':zh[label]})
    assert len(implementations)==len(rows)==65
    assert all(k in en for k in inventory['labels_A'])
    baseline=hashlib.sha256((ROOT/'reproduction/new_baseline.json').read_bytes()).hexdigest()
    report={'stage':'最终实施映射；原只读审核另行冻结保留','audit_source':'reviews/fusion_audit/fusion_audit_stage1.json',
            'A_sha256':original['A_sha256'],'B_sha256':original['B_sha256'],'baseline_sha256':baseline,
            'rows':rows,'reference_checks':original['reference_checks'],'label_migration':migration,
            'notation':load('provenance/fusion_notation_map.json'),
            'counts':{'audit_rows':len(rows),'reference_checks':len(original['reference_checks']),
                      'original_labels':len(inventory['labels_A']),'final_labels':len(en),'new_labels':len(en)-len(inventory['labels_A']),
                      'decisions':dict(collections.Counter(r['decision'] for r in rows))},
            'evidence_status':[ ['已证明（所列局部假设下）','运输及相容、端点生成、实际闭环的结构条件与有限时间误差估计'],
                               ['已复算','1880项FE比对；12类符号恒等式；56个方法/步长结果；两套正规形预算'],
                               ['条件性结论','自治保守映射或保守参考的KAM；共同复域；净空与高模态推广条件'],
                               ['尚待完成','完整CHNN、64模态闭环、独立COMSOL、器件标定、能量治理器、有限幅值KAM证书'] ]}
    (ROOT/'reviews/fusion_audit_final.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report['counts'],ensure_ascii=False))

if __name__=='__main__':main()
