from pathlib import Path
import json
import sympy as s
q1,q2,p1,p2=s.symbols('q1 q2 p1 p2'); z=s.Matrix([q1,q2,p1,p2]); n=4
R=s.Matrix([s.Function('R'+str(i))(*z) for i in range(n)])
f=s.Matrix([s.Function('f'+str(i))(*z) for i in range(n)])
DR=R.jacobian(z); Df=f.jacobian(z); K=DR.T-DR
Rt=-DR*f-Df.T*R
B=(R.T*f)[0]
checks={}
checks['transport_to_birkhoff_all_four_components']=all(s.simplify(x)==0 for x in K*f-s.Matrix([s.diff(B,zi) for zi in z])-Rt)
Kt=Rt.jacobian(z).T-Rt.jacobian(z)
LfK=sum((f[j]*K.diff(z[j]) for j in range(n)),s.zeros(n))+Df.T*K+K*Df
checks['time_compatibility_all_16_components']=all(s.simplify(x)==0 for x in Kt+LfK)
checks['spatial_closure_all_index_triples']=all(s.simplify(s.diff(K[i,j],z[k])+s.diff(K[j,k],z[i])+s.diff(K[k,i],z[j]))==0 for i in range(n) for j in range(n) for k in range(n))
I=s.eye(2);O=s.zeros(2);J=O.row_join(I).col_join((-I).row_join(O));K0=-J
T0=s.diag(1,1,-1,-1);E=T0*J
Tp=s.Matrix(n,n,s.symbols('tp0:16'));Tm=s.Matrix(n,n,s.symbols('tm0:16'))
DA=(E*Tp).row_join(-E*Tm).col_join((T0*Tp/2).row_join(T0*Tm/2))
J8=s.zeros(n).row_join(s.eye(n)).col_join((-s.eye(n)).row_join(s.zeros(n)))
expected=s.diag(Tp.T*K0*Tp,-Tm.T*K0*Tm)
checks['A_endpoint_congruence_all_64_components']=all(s.expand(x)==0 for x in DA.T*J8*DA-expected)
DB=(J*Tp).row_join(-J*Tm).col_join((Tp/2).row_join(Tm/2))
checks['endpoint_conventions_exactly_related']=DA==s.diag(T0,T0)*DB
N=s.Matrix([[s.Function('N11')(q1,q2),s.Function('N12')(q1,q2)],[s.Function('N12')(q1,q2),s.Function('N22')(q1,q2)]])
p=z[2:,:];V=s.Function('V')(q1,q2);Q=s.Matrix([s.Function('Q1')(*z),s.Function('Q2')(*z)])
H=(p.T*N*p)[0]/2+V
fm=s.Matrix([s.diff(H,p1),s.diff(H,p2),-s.diff(H,q1)+Q[0],-s.diff(H,q2)+Q[1]])
R0=s.Matrix([p1,p2,0,0]);R1=-R0.jacobian(z)*fm-fm.jacobian(z).T*R0
expected1=s.Matrix([s.diff(V,qi)-(p.T*N.diff(qi)*p)[0]/2-Q[i] for i,qi in enumerate([q1,q2])]).col_join(-N*p)
checks['configuration_dependent_mass_first_transport_coefficient']=all(s.simplify(x)==0 for x in R1-expected1)
vel=s.Matrix(s.symbols('v0:4')); Rt_free=s.Matrix(s.symbols('Rt0:4'))
B_free=s.Function('B')(*z)
LB=(R.T*vel)[0]-B_free
euler=s.Matrix([s.diff(LB,zi) for zi in z])-DR*vel-Rt_free
expected_euler=K*vel-s.Matrix([s.diff(B_free,zi) for zi in z])-Rt_free
checks['Euler_multiplier_identity_all_four_components']=all(s.simplify(x)==0 for x in euler-expected_euler)
sigma=s.Function('sigma')(*z); sigmat=s.Function('sigmat')(*z)
grad_sigma=s.Matrix([s.diff(sigma,zi) for zi in z]); grad_sigmat=s.Matrix([s.diff(sigmat,zi) for zi in z])
DR_gauge=(R+grad_sigma).jacobian(z)
checks['gauge_leaves_K_unchanged']=all(s.simplify(x)==0 for x in DR_gauge.T-DR_gauge-K)
checks['gauge_leaves_B_gradient_plus_R_time_unchanged']=all(s.simplify(x)==0 for x in s.Matrix([s.diff(B_free-sigmat,zi) for zi in z])+Rt_free+grad_sigmat-s.Matrix([s.diff(B_free,zi) for zi in z])-Rt_free)
aa,bb=s.symbols('a damping_estimate',nonzero=True)
Rhat=s.Function('Rhat')(q1,q2)
potential_v=s.Matrix([0,0,s.diff(Rhat,q1),s.diff(Rhat,q2)])
checks['potential_control_compatible_with_same_K']=all(s.simplify(x)==0 for x in aa*K0*potential_v-s.Matrix([s.diff(-aa*Rhat,zi) for zi in z]))
damping_form=aa*K0*s.Matrix([0,0,bb*p1,bb*p2]); D_damping_form=damping_form.jacobian(z)
checks['damping_control_curl_equals_nonzero_a_gammahat_J']=D_damping_form.T-D_damping_form==aa*bb*J
checks['central_generator_sign_preserves_A_endpoint_convention']=-E*T0==J
assert all(checks.values()),checks
out={'status':'all exact symbolic identities passed','dimension':4,'sympy':s.__version__,'checks':checks,'scope':'Generic component and block algebra only; not a certificate of global existence, KAM, or numerical chart accuracy.'}
(Path(__file__).resolve().parent/'general_identity_checks.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
