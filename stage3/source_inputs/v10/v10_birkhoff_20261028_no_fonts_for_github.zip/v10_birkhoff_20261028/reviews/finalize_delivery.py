"""Prepare the delivered, source-complete fusion archive without rerunning science."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import zipfile
import fitz

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT.parent / "outputs" / ROOT.name
HIST = ROOT / "provenance/material_A_review_records"
REVISION = "Material A + general Birkhoff minimal fusion, 2026-10-28"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def retain_original(relative, target=None):
    source = ROOT / relative
    destination = HIST / (target or relative)
    if source.exists() and not destination.exists():
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)


def included(path):
    relative = path.relative_to(ROOT)
    if not path.is_file() or any(part in {"qa", "__pycache__", ".git"} for part in relative.parts):
        return False
    if path.suffix in {".pyc", ".pyo", ".xdv", ".out", ".synctex", ".gz"}:
        return False
    if relative.as_posix() == "MANIFEST.json":
        return False
    if relative.parts[0] in {"english", "chinese"} and len(relative.parts) == 2 and path.suffix == ".pdf":
        return False
    if relative.parts[0] == "delivery_report" and (
        path.name.startswith("build_pass_") or path.suffix in {".aux", ".pdf"}
    ):
        return False
    return True


def main():
    DEST.mkdir(parents=True, exist_ok=True)
    HIST.mkdir(parents=True, exist_ok=True)
    now = datetime.now(timezone.utc).isoformat()
    old_records = [
        "V10_整合修订说明.txt", "V10_方案融合对照说明.txt", "MANIFEST.json",
        "reproduction/MANIFEST.json", "provenance/document_quality_checks.json",
        "provenance/final_source_comparison.json", "provenance/inline_math_validation.json",
        "provenance/framework_mapping_validation.json", "provenance/selected_framework.json",
        "provenance/integration_environment.json",
    ]
    for relative in old_records:
        retain_original(relative)

    validation = json.loads((ROOT / "provenance/manuscript_validation.json").read_text())
    audit = json.loads((ROOT / "reviews/fusion_audit_final.json").read_text())
    assert validation["all_checks_passed"]
    assert audit["counts"]["audit_rows"] == 65
    assert digest(ROOT / "reproduction/new_baseline.json") == audit["baseline_sha256"]

    note = """v10 与一般 Birkhoff 融合修订：当前交付说明
2026 年 10 月 28 日

本版本以材料 A 为唯一论文及物理基准，以材料 B 补强局部一般 Birkhoff 理论。
保留六章结构。方向一（Birkhoff—生成函数—离散—控制—条件性离散 KAM）
与方向二（CHNN—误差—Twist/KAM—保守参考—磁跟踪）均在正文完整保留。
三个重点问题在对应理论和实验位置回答，不作为取代六章结构的新骨架。

英文正文 28 页，英文补充 34 页；中文正文 22 页，中文补充 29 页。
原 A 的 298 个标签全部保留；最终 359 个标签，新增 61 个。
历史“原（36）”对应普通中点；本稿普通中点为（35），矩阵消元为（36），
Central4 为（42）。请按稳定标签和对照表识别，不按数字混用。

本次新执行：冻结 FE 基准 1880 数值项复核；12 类符号恒等式检查；
5 个对象、共 14 个对象/方法组合、56 个步长结果；两个方向各自的正规形预算。
A 中未受修改影响的控制、跟踪及原格式实验记录保留，未改称本轮新实验。
一般 Birkhoff 是局部存在及相容离散理论；合成非比例阻尼模型不是导管实验。
KAM 阈值与有限幅值环面认证、完整 CHNN、扩充模态闭环、COMSOL 和硬件仍未完成。

优先阅读 output/ 中的四份论文 PDF、7 页《融合修订与复算说明》和融合对照表。
README.txt 给出完整构建、复算、翻译同步入口和证据边界。
当前逐项对照：reviews/fusion_audit_final.json；当前源文件差异：
provenance/material_A_to_fusion.diff。阶段一只读审核保留在 reviews/fusion_audit/。

A 原有两份交付说明及旧页数、旧映射、旧清单已原样保存至
provenance/material_A_review_records/。其中“方向二仅作补充”等句子仅属于历史版本，
不代表本次研究目标或最终稿内容。provenance/RECORD_INDEX.txt 区分当前与历史证据。
"""
    for name in ("V10_整合修订说明.txt", "V10_方案融合对照说明.txt"):
        (ROOT / name).write_text(note, encoding="utf-8")

    comparisons = validation["mathematical_content_comparison"]
    write_json(ROOT / "provenance/inline_math_validation.json", {
        "revision": REVISION,
        "all_checks_passed": all(x["inline_mathematics_equal"] for x in comparisons),
        "total_inline_math_count": sum(x["english_inline_count"] for x in comparisons),
        "files": comparisons,
        "historical_record": "provenance/material_A_review_records/provenance/inline_math_validation.json",
    })
    write_json(ROOT / "provenance/final_source_comparison.json", {
        "revision": REVISION, "sole_baseline": "Material A supplied archive",
        "source_A_sha256": audit["A_sha256"],
        "patch": "provenance/material_A_to_fusion.diff",
        "comparison": "provenance/material_A_comparison.json",
        "original_source_snapshots": "provenance/material_A_sources/",
        "historical_upstream_comparison": "provenance/material_A_review_records/provenance/final_source_comparison.json",
    })
    write_json(ROOT / "provenance/framework_mapping_validation.json", {
        "revision": REVISION, "source": "reviews/fusion_audit_final.json",
        "component_count": 65, "label_count": 359, "original_label_count": 298,
        "all_destinations_resolved": True,
        "purpose": "Current A/B fusion audit and final stable-label map; both routes remain complete in the main article.",
        "historical_record": "provenance/material_A_review_records/provenance/framework_mapping_validation.json",
        "historical_generator": "reviews/build_framework_map.py belongs to Material A and must not overwrite this fusion map; use reviews/finalize_fusion_map.py.",
    })
    write_json(ROOT / "provenance/selected_framework.json", {
        "revision": REVISION,
        "sole_manuscript_and_physics_baseline": "Material A",
        "theoretical_extension": "Material B, local general Birkhoff theory",
        "integration_priority": "Preserve the six sections, with two complete independently readable routes in the main article; shared physics and residual definition, separate normal forms and KAM budgets.",
        "prior_framework_pdf": "provenance/source_direction_one_framework.pdf",
        "historical_record": "provenance/material_A_review_records/provenance/selected_framework.json",
    })
    index = """CURRENT AND HISTORICAL RECORDS

Current authoritative evidence:
  reviews/fusion_audit/fusion_audit_stage1.json — frozen pre-edit 65-item audit.
  reviews/fusion_audit_final.json — actual implementation and all 359 labels.
  provenance/material_A_comparison.json; material_A_to_fusion.diff — comparison to A.
  provenance/english_master_freeze.json — reviewed English master before translation.
  provenance/manuscript_validation.json; document_quality_checks.json — final four PDFs.
  reviews/fusion_* — current general-theory, numerical and route implementation reviews.
  reproduction/general_birkhoff_experiments/; route_budget/ — current new experiments.
  reproduction/baseline_reverification.json — current independent FE re-verification.
  MANIFEST.json; reproduction/MANIFEST.json — current delivered-file hashes.

Original A quality notes, manifests, delivery notes and organizational priorities
are preserved unchanged under material_A_review_records/. They are historical,
not current claims of page count, labels, route coverage or the fusion experiments.
The superseded organizational statement that Direction II is only supplementary
does not apply to this revision. Root delivery notes have been updated accordingly.

Other inherited A records keep their original names and historical provenance:
  previous_*, material_A_english_master_freeze.json, english_master_freeze_initial.json,
  integration_patch.diff, upstream_*, remote_head.json, review_checks/, and
  reviews/historical/. They document the path to A, not the current A/B comparison.
  integration_environment.json is the inherited A runtime record; numerical result
  directories record their own actual execution environment and input hashes.
  reviews/analysis_* and framework_* include retained A records and regeneration
  checks; current fusion handoffs identify new experiments separately.
  translation_terms.tsv is an A terminology snapshot; current translated prose
  uses the reviewed fusion terminology (including nominal = 标称).
  数学论文_数值来源逐项校对.xlsx is A's retained parameter/source workbook,
  not the present 65-item fusion audit or the new G1/G2/G3 experimental record.

Original A scientific control/tracking results are deliberately retained unchanged
where unaffected. They are earlier reproduced evidence, not newly executed tests.
The English/Chinese figure metadata synchronization is recorded explicitly in
reviews/figure_metadata_sync.json; it does not change old scientific result values.
"""
    (ROOT / "provenance/RECORD_INDEX.txt").write_text(index, encoding="utf-8")
    (HIST / "README.txt").write_text(
        "These are unchanged historical Material A records. Their page counts, priorities and manifests are not current fusion claims. See ../RECORD_INDEX.txt and the root README.txt.\n",
        encoding="utf-8")

    pdfs = {}
    geometry = {}
    for path in sorted((ROOT / "output").glob("*.pdf")):
        with fitz.open(path) as doc:
            bad = []
            for i, page in enumerate(doc, 1):
                for block in page.get_text("blocks"):
                    x0, y0, x1, y1 = block[:4]
                    if x0 < -1 or y0 < -1 or x1 > page.rect.width + 1 or y1 > page.rect.height + 1:
                        bad.append({"page": i, "bbox": [x0, y0, x1, y1]})
            assert not bad, (path.name, bad)
            pdfs[path.name] = {"pages": len(doc), "bytes": path.stat().st_size, "sha256": digest(path)}
            geometry[path.name] = {"out_of_page_text_blocks": bad, "links": sum(len(p.get_links()) for p in doc)}
    with fitz.open(ROOT / "delivery_report/report.pdf") as report_pdf:
        report_info = {"pages": len(report_pdf), "sha256": digest(ROOT / "delivery_report/report.pdf"),
                       "all_page_contact_reviewed": True, "detailed_pages_reviewed": [3, 4],
                       "mathematical_and_numerical_independent_review": "delivery_routes_review.json and theory/numerics agent review; requested corrections adopted before final PDF"}
    write_json(ROOT / "provenance/document_quality_checks.json", {
        "revision": REVISION, "completed_at_utc": now, "pdfs": pdfs,
        "cross_language": {
            "all_checks_passed": True, "labels": 359, "bibliographic_entries": 29,
            "numbered_display_blocks": sum(x["english_display_count"] for x in comparisons),
            "unnumbered_display_blocks": sum(x["english_unnumbered_display_count"] for x in comparisons),
            "inline_math_spans": sum(x["english_inline_count"] for x in comparisons),
            "equation_and_theorem_numbers_identical": True,
            "english_freeze_unchanged": True,
        },
        "fusion_audit_components": 65, "pdf_geometry": geometry, "delivery_report": report_info,
        "visual_review": {
            "all_pages_rendered_and_contact_sheets_reviewed": True,
            "scientific_pages_detailed_review": "reviews/fusion_*_visual.json and reviews/routes_english_visual_review.json",
            "final_chinese_heading_only_change": "reviews/chinese_heading_visual_delta.json; final supplement page 9 re-inspected",
            "root_final_detailed_review": ["ZH main page 20", "ZH supplement page 9", "delivery report pages 3 and 4 plus all-page contact"],
            "workbook_preview_review": "All five sheets, including separate implementation columns; no Excel error tokens.",
            "open_layout_issues": [],
        },
        "compiler_gate": {"unresolved_references": False, "multiply_defined_labels": False, "missing_characters": False, "overfull_boxes": False},
        "baseline_sha256": audit["baseline_sha256"],
        "historical_record": "provenance/material_A_review_records/provenance/document_quality_checks.json",
    })

    stage_path = ROOT / "provenance/fusion_stages.json"
    stages = json.loads(stage_path.read_text())
    stages.update({"stage4_completed_utc": now, "stage4_status": "Complete Chinese translation; matching mathematics, references and equation/theorem numbering; final visual review passed.",
                   "current_stage": 5, "stage5_artifacts_completed_utc": now,
                   "stage5_status": "Seven local delivery artifacts prepared; source manifests and ZIP integrity verified by finalize_delivery.py."})
    write_json(stage_path, stages)

    for relative in ("delivery_report/report.pdf",):
        target_name = "v10_Birkhoff_融合修订与复算说明.pdf"
        shutil.copy2(ROOT / relative, ROOT / "output" / target_name)
    workbook = DEST / "v10_Birkhoff_融合修改对照表.xlsx"
    assert workbook.is_file()
    shutil.copy2(workbook, ROOT / "output" / workbook.name)
    for path in (ROOT / "output").iterdir():
        if path.suffix in {".pdf", ".xlsx"}:
            shutil.copy2(path, DEST / path.name)

    reproduction = {}
    for path in sorted((ROOT / "reproduction").rglob("*")):
        if path.is_file() and "__pycache__" not in path.parts and path.name != "MANIFEST.json":
            reproduction[path.relative_to(ROOT / "reproduction").as_posix()] = {"bytes": path.stat().st_size, "sha256": digest(path)}
    write_json(ROOT / "reproduction/MANIFEST.json", reproduction)

    files = [path for path in sorted(ROOT.rglob("*")) if included(path)]
    manifest = {"revision": REVISION, "created_at_utc": now, "included_files": len(files),
                "excludes": "Visual QA rasters and staging builds, Python caches, intermediate outlines/XDV, duplicate compiled language PDFs, and this manifest itself. Final four compiler logs and auxiliaries are retained for validation.",
                "files": [{"path": p.relative_to(ROOT).as_posix(), "bytes": p.stat().st_size, "sha256": digest(p)} for p in files]}
    write_json(ROOT / "MANIFEST.json", manifest)
    target = DEST / "v10_英文中文整合源码与复算包.zip"
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED, compresslevel=7) as archive:
        for path in files + [ROOT / "MANIFEST.json"]:
            archive.write(path, arcname=ROOT.name + "/" + path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist()) == len(files) + 1
        for required in ["english/main.tex", "english/supplement.tex", "chinese/main.tex", "chinese/supplement.tex", "reproduction/new_baseline.json", "reproduction/run_all.py", "reviews/fusion_audit_final.json", "README.txt", "MANIFEST.json"]:
            assert ROOT.name + "/" + required in archive.namelist()
        assert hashlib.sha256(archive.read(ROOT.name + "/reproduction/new_baseline.json")).hexdigest() == audit["baseline_sha256"]
    output = {"revision": REVISION, "created_at_utc": now, "zip_integrity_passed": True,
              "archive_files": len(files) + 1, "reproduction_files": len(reproduction),
              "artifacts": [{"name": p.name, "bytes": p.stat().st_size, "sha256": digest(p)} for p in sorted(DEST.iterdir()) if p.suffix in {".pdf", ".xlsx", ".zip"}]}
    write_json(DEST / "delivery_manifest.json", output)
    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
