"""Check the KAM/route-interface translations against the frozen English master."""
from pathlib import Path
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("manuscript_validator", ROOT / "reviews/validate_manuscripts.py")
VALIDATOR = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VALIDATOR)
FILES = [
    "kam.tex", "extension_tracking_theory.tex", "route_interfaces.tex",
    "tracking_main.tex", "supp_route_budgets.tex", "route_budget_table.tex",
    "route_budget_main_values.tex", "extension_tracking_results.tex",
]


def main():
    comparisons = []
    for filename in FILES:
        english = ROOT / "english/sections" / filename
        chinese = ROOT / "chinese/sections" / filename
        left = VALIDATOR.without_comments(english.read_text())
        right = VALIDATOR.without_comments(chinese.read_text())
        row = {"file": filename, "english_sha256": hashlib.sha256(english.read_bytes()).hexdigest(),
               "chinese_sha256": hashlib.sha256(chinese.read_bytes()).hexdigest()}
        for name, pattern in (("display", VALIDATOR.DISPLAY),
                              ("unnumbered_display", VALIDATOR.UNNUMBERED_DISPLAY),
                              ("inline", VALIDATOR.INLINE)):
            a, b = pattern.findall(left), pattern.findall(right)
            if name == "display":
                a, b = [x[1] for x in a], [x[1] for x in b]
            a, b = list(map(VALIDATOR.math_key, a)), list(map(VALIDATOR.math_key, b))
            row[name] = {"count": len(a), "identical_in_order": a == b}
            assert a == b, (filename, name, "mathematical content differs")
        for name, pattern in (("labels", VALIDATOR.LABEL), ("references", VALIDATOR.REFERENCE),
                              ("citations", VALIDATOR.CITATION)):
            a, b = pattern.findall(left), pattern.findall(right)
            row[name] = {"count": len(a), "identical_in_order": a == b}
            assert a == b, (filename, name, "identifier sequence differs")
        comparisons.append(row)

    freeze = json.loads((ROOT / "provenance/english_master_freeze.json").read_text())
    for relative, expected in freeze["files"].items():
        assert hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() == expected, relative
    result_file = ROOT / "reproduction/route_budget/normal_form_budget_results.json"
    report = {
        "stage": "4 Chinese translation of frozen English KAM and two-route content",
        "all_checks_passed": True,
        "english_master_unchanged": True,
        "files": comparisons,
        "numerical_result_sha256": hashlib.sha256(result_file.read_bytes()).hexdigest(),
        "generated_fragments": {
            "command": "PYTHONPATH=/tmp/v10_birkhoff_dependencies python3 reproduction/route_budget/run_all.py --render-existing --language zh",
            "new_calculation": False,
            "generator_edit_scope": "Chinese prose branch only; identical numerical source and formula renderer.",
        },
        "retained_results": "extension_tracking_results.tex was retained unchanged in both languages.",
        "pending_at_handoff": "Root compilation and visual verification of the Chinese PDFs.",
    }
    (ROOT / "reviews/fusion_routes_translation_check.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"all_checks_passed": True, "files": len(FILES),
                      "display_blocks": sum(r["display"]["count"] for r in comparisons),
                      "unnumbered_display_blocks": sum(r["unnumbered_display"]["count"] for r in comparisons),
                      "inline_math_blocks": sum(r["inline"]["count"] for r in comparisons),
                      "english_master_unchanged": True}, ensure_ascii=False))


if __name__ == "__main__":
    main()
